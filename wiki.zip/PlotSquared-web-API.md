﻿|Contents|  
|--------|
|[worlds](https://github.com/IntellectualCrafters/PlotSquared/wiki/PlotSquared-web-API#worlds)|
|[uuids](https://github.com/IntellectualCrafters/PlotSquared/wiki/PlotSquared-web-API#uuids)|
|[plots](https://github.com/IntellectualCrafters/PlotSquared/wiki/PlotSquared-web-API#plots)|
|[unimplemented](https://github.com/IntellectualCrafters/PlotSquared/wiki/PlotSquared-web-API#unimplemented)|

### WORLDS

###### METHOD
GET

###### PATH
/worlds

###### PARAMETERS
 - `world=<name>`

###### EXAMPLE
/worlds?world=plotworld

###### RESULT
``` JSON
[{
 "terrain": 0,
 "home": {
  "default": "5,5",
  "allow-nonmember": false
 },
 "flags": [],
 "pvp": false,
 "economy": false,
 "type": 0,
 "mob-spawning": false,
 "world-border": false,
 "spawn": {
  "breeding": false,
  "custom": false
 },
 "pve": false,
 "worldname": "plotworld",
 "price": {
  "sell": 75,
  "buy": 100
 },
 "allow-signs": true,
 "generator": "PlotSquared",
 "auto-merge": false
}]
```
### UUIDS

###### METHOD
GET

###### PATH
/uuids

###### PARAMETERS
 - `<uuid>`
 - `<name>`

###### EXAMPLE
/uuid?Empire92&invalid&5972a1ee-c42e-3b97-b71e-17d403a6a9b9

###### RESULT
``` JSON

[
 {
  "input": "Empire92",
  "name": "Empire92",
  "uuid": "5972a1ee-c42e-3b97-b71e-17d403a6a9b9"
 },
 {
  "input": "invalid",
  "name": "invalid",
  "uuid": ""
 },
 {
  "input": "5972a1ee-c42e-3b97-b71e-17d403a6a9b9",
  "name": "Empire92",
  "uuid": "5972a1ee-c42e-3b97-b71e-17d403a6a9b9"
 }
]
```
### PLOTS

###### METHOD
GET

###### PATH
/plots

###### PARAMETERS
 - `world=<world>`
 - `id=<X;Z>`
 - `owner=<name|uuid>`
 - `trusted=<name|uuid>`
 - `helpers=<name|uuid>`
 - `denied=<name|uuid>`
 - `allowed=<name|uuid>`
 - `cluster=<cluster>`
 - `alias=<alias>`
 - `merged=<true|false>`

###### EXAMPLE
/plots?world=plotworld

###### RESULT
``` JSON
[
 {
  "ownerUUID": "00000001-0001-0003-0003-000000000007",
  "id": {
   "y": 18,
   "x": 22
  },
  "home": {
   "z": 0,
   "y": 0,
   "x": 0
  },
  "ownerName": "*",
  "trusted": [],
  "flags": [],
  "alias": "",
  "denied": [],
  "merged": false,
  "world": "plot",
  "helpers": ["5972a1ee-c42e-3b97-b71e-17d403a6a9b9"]
 },
 {
  "ownerUUID": "5972a1ee-c42e-3b97-b71e-17d403a6a9b9",
  "id": {
   "y": 19,
   "x": 23
  },
  "home": {
   "z": 0,
   "y": 0,
   "x": 0
  },
  "ownerName": "Empire92",
  "trusted": [],
  "flags": [],
  "alias": "",
  "denied": [],
  "merged": false,
  "world": "plot",
  "helpers": []
 },
 {
  "ownerUUID": "5972a1ee-c42e-3b97-b71e-17d403a6a9b9",
  "id": {
   "y": 21,
   "x": 24
  },
  "home": {
   "z": 0,
   "y": 0,
   "x": 0
  },
  "ownerName": "Empire92",
  "trusted": [],
  "flags": [],
  "alias": "",
  "denied": [],
  "merged": false,
  "world": "plot",
  "helpers": []
 },
 {
  "ownerUUID": "5972a1ee-c42e-3b97-b71e-17d403a6a9b9",
  "id": {
   "y": 19,
   "x": 24
  },
  "home": {
   "z": 0,
   "y": 0,
   "x": 0
  },
  "ownerName": "Empire92",
  "trusted": [],
  "flags": [],
  "alias": "",
  "denied": [],
  "merged": false,
  "world": "plot",
  "helpers": []
 },
 {
  "ownerUUID": "00000001-0001-0003-0003-000000000007",
  "id": {
   "y": 3,
   "x": 3
  },
  "home": {
   "z": 0,
   "y": 0,
   "x": 0
  },
  "ownerName": "*",
  "trusted": [],
  "flags": ["animal-interact:true"],
  "alias": "",
  "denied": [],
  "merged": false,
  "world": "plot",
  "helpers": []
 },
 {
  "ownerUUID": "5972a1ee-c42e-3b97-b71e-17d403a6a9b9",
  "id": {
   "y": 20,
   "x": 23
  },
  "home": {
   "z": 0,
   "y": 0,
   "x": 0
  },
  "ownerName": "Empire92",
  "trusted": [],
  "flags": [
   "mob-cap:10",
   "explosion:true"
  ],
  "alias": "",
  "denied": [],
  "merged": false,
  "world": "plot",
  "helpers": []
 },
 {
  "ownerUUID": "5972a1ee-c42e-3b97-b71e-17d403a6a9b9",
  "id": {
   "y": 19,
   "x": 22
  },
  "home": {
   "z": 0,
   "y": 0,
   "x": 0
  },
  "ownerName": "Empire92",
  "trusted": [],
  "flags": ["forcefield:true"],
  "alias": "",
  "denied": [],
  "merged": false,
  "world": "plot",
  "helpers": []
 },
 {
  "ownerUUID": "5972a1ee-c42e-3b97-b71e-17d403a6a9b9",
  "id": {
   "y": 21,
   "x": 23
  },
  "home": {
   "z": 0,
   "y": 0,
   "x": 0
  },
  "ownerName": "Empire92",
  "trusted": [],
  "flags": [],
  "alias": "",
  "denied": [],
  "merged": false,
  "world": "plot",
  "helpers": []
 },
 {
  "ownerUUID": "00000001-0001-0003-0003-000000000007",
  "id": {
   "y": 14,
   "x": 22
  },
  "home": {
   "z": 0,
   "y": 0,
   "x": 0
  },
  "ownerName": "*",
  "trusted": [],
  "flags": [],
  "alias": "",
  "denied": [],
  "merged": false,
  "world": "plot",
  "helpers": []
 },
 {
  "ownerUUID": "00000001-0001-0003-0003-000000000007",
  "id": {
   "y": 15,
   "x": 23
  },
  "home": {
   "z": 0,
   "y": 0,
   "x": 0
  },
  "ownerName": "*",
  "trusted": [],
  "flags": [],
  "alias": "",
  "denied": [],
  "merged": true,
  "world": "plot",
  "helpers": []
 },
 {
  "ownerUUID": "5972a1ee-c42e-3b97-b71e-17d403a6a9b9",
  "id": {
   "y": 14,
   "x": 21
  },
  "home": {
   "z": 0,
   "y": 0,
   "x": 0
  },
  "ownerName": "Empire92",
  "trusted": [],
  "flags": [],
  "alias": "",
  "denied": [],
  "merged": false,
  "world": "plot",
  "helpers": []
 },
 {
  "ownerUUID": "00000001-0001-0003-0003-000000000007",
  "id": {
   "y": 14,
   "x": 23
  },
  "home": {
   "z": 0,
   "y": 0,
   "x": 0
  },
  "ownerName": "*",
  "trusted": [],
  "flags": [],
  "alias": "",
  "denied": [],
  "merged": true,
  "world": "plot",
  "helpers": ["5972a1ee-c42e-3b97-b71e-17d403a6a9b9"]
 },
 {
  "ownerUUID": "5972a1ee-c42e-3b97-b71e-17d403a6a9b9",
  "id": {
   "y": 20,
   "x": 24
  },
  "home": {
   "z": 0,
   "y": 0,
   "x": 0
  },
  "ownerName": "Empire92",
  "trusted": [],
  "flags": [],
  "alias": "",
  "denied": [],
  "merged": false,
  "world": "plot",
  "helpers": []
 },
 {
  "ownerUUID": "5972a1ee-c42e-3b97-b71e-17d403a6a9b9",
  "id": {
   "y": 4,
   "x": 3
  },
  "home": {
   "z": 0,
   "y": 0,
   "x": 0
  },
  "ownerName": "Empire92",
  "trusted": [],
  "flags": [],
  "alias": "",
  "denied": [],
  "merged": false,
  "world": "plot",
  "helpers": []
 }
]
```
e.g. 2
for `/plots?world=plot&id=50;50`
``` JSON
[{
 "id": {
  "y": 50,
  "x": 50
 },
 "home": {
  "z": 0,
  "y": 0,
  "x": 0
 },
 "ownerName": "",
 "trusted": [],
 "flags": [],
 "alias": "",
 "denied": [],
 "merged": false,
 "world": "plot",
 "helpers": []
}]
```
### UNIMPLEMENTED
 - clusters
 - comments
 - schematics
