﻿Placeholders allow you to display data from PlotSquared in other plugins using FeatherBoard or PlaceholderAPI.
## How to use placeholders?

### Download the placeholder API you need.

As of 5.0, PlotSquared natively supports [**PlaceholderAPI**](https://www.spigotmc.org/resources/placeholderapi.6245/) and [**MVdWPlaceholderAPI**](https://www.spigotmc.org/resources/mvdwplaceholderapi.11182/).

### Launch the server and you're ready to go!

Regardless of the placeholder API you're using, just start the server. There are **no expansions to download**: PlotSquared handles everything internally!

## How to display a placeholder in the chat?

If you're using **EssentialsChat** and **PlaceholderAPI**, you **must** install [**ChatInjector**](https://www.spigotmc.org/resources/chatinjector.38327/) in order for the placeholders to show up in the chat. However, please note it has been reported that ChatInjector might cause issues.

We recommend you to use an alternative chat plugin which supports PlaceholderAPI, such as [**DeluxeChat**](https://www.spigotmc.org/resources/deluxechat.1277/).    
To display them via PlaceholderAPI use the following format: `%plotsquared_<placeholder>%`    
To display them via FeatherBoard use the following format: `{placeholderapi_plotsquared_<placeholder>}`

## How to suggest a new placeholder?

If you think a placeholder for PlotSquared should be added, then please submit us a [placeholder request](https://github.com/IntellectualSites/PlotSquaredSuggestions/issues/new/choose).

**Available placeholders in 5.0**

| Placeholder | Description | 
|-------------------------------------------------------|--------------------------------------------------------------------------------|
| %plotsquared_currentplot_alias% | Alias of the plot |
| %plotsquared_currentplot_owner% | Owner of the plot |
| %plotsquared_currentplot_members% | Amount of players added and trusted to the plot | 
| %plotsquared_currentplot_members_added% | Amount of players added to the plot | 
| %plotsquared_currentplot_members_trusted% | Amount of players trusted to the plot| 
| %plotsquared_currentplot_members_denied% | Amount of members denied from the plot |
| %plotsquared_world_name% | Get the name of the world | 
| %plotsquared_has_plot% | Displays true or false whether the player has plot | 
| %plotsquared_has_plot_(world)% | Displays true or false whether the player has plot in a specific world | 
| %plotsquared_has_build_rights% | Displays true or false whether the player has build rights on the plot |
| %plotsquared_plot_count% | Amount of global plots of a player |
| %plotsquared_plot_count_(World)% | Amount of plots for a player in a specific world |
| %plotsquared_allowed_plot_count% | Amount of maximum plots a player can have |
| %plotsquared_currentplot_xy% | Displays the X and Y ID of a plot |
| %plotsquared_currentplot_x% | Displays the X ID of a plot |
| %plotsquared_currentplot_y% | Displays the Y ID of a plot |
| %plotsquared_currentplot_rating% | Displays the average rating of a plot |
| %plotsquared_currentplot_biome% | Displays the biome of a plot |


# Use PlaceholderAPI placeholders in PlotSquared
PlotSquared messages and flags support PlaceholderAPI placeholders. The only requirement is that [PAPI](https://www.spigotmc.org/resources/placeholderapi.6245/) is installed on the server.

As an example, using `/plot flag set greeting Welcome %player_name%` will send the message "Welcome Steve" when the player Steve enters a plot.

This feature can be completely disabled in `settings.yml`. A list of available placeholders can be found [here](https://github.com/PlaceholderAPI/PlaceholderAPI/wiki/Placeholders). 
