﻿Located in: `/plugins/PlotSquared/config/worlds.yml`

This file contains the configuration for each world.

```YML
worlds:
 # The name of the world
 plotworld:
  # Configure what generates in the plot
  plot:
   height: 64
   biome: FOREST
   size: 42
   # Can use item names or numbers
   filling:
   - 'stone'
   - '5:5'
   auto_merge: false
   bedrock: true
   create_signs: true
   floor:
   - '2:0'
  # Configure the wall
  wall:
   filling: '1:0'
   block_claimed: '44:1'
   height: 64
   block: '44:0'
  # Configure the road
  road:
   block: '155:0'
   height: 64
   width: 7
  # Configure the home
  home:
   # side or center or x,z or x,y,z
   default: side
   # Allows people not added to the plot to use the home set by `/plot sethome`
   allow-nonmembers: false
  # Paste a schematic on claim
  schematic:
    # Requires the user to specify a schematic when they use /plot claim <schem>
   specify_on_claim: false
    # Pastes the configured SCHEMATIC_FILE
   on_claim: false
   file: 'null'
  # Command costs
  economy:
   use: false
   prices:
    # Can use javascript for dynamic prices
    claim: 100*{arg}+50
    sell: 100
    merge: 100
  # Default plot chat mode (toggled with `/plot toggle chat`)
  chat:
   enabled: false
  # Limit the number of people that can be added to a plot
  limits:
   max-members: 128
  world:
   # Build height
   min_height: 1
   max_height: 256
   # Used for the gamemode flag
   gamemode: creative
   # World border expands dynamically
   border: false
  # False = disabled
  event:
   spawn:
    egg: false
    breeding: false
    custom: true
  natural_mob_spawning: false
  mob_spawner_spawning: false
  # Controls the world type / terrain / generator used
  generator:
   type: 0
   terrain: 0
   plugin: PlotSquared
  # See: https://github.com/IntellectualSites/PlotSquared/wiki/Usage:-Plot-flags#default-flags
  flags: {}
```
