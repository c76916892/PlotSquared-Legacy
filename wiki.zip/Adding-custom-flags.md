﻿# Table of Contents
1. [Adding custom flags in PlotSquared 4](#adding-custom-flags-in-plotsquared-4)
   1. [Using Bukkit](#using-bukkit)
2. [Adding custom flags in PlotSquared <= 1.12](#adding-custom-flags-in-plotsquared--112)

## Adding custom flags in PlotSquared 4

### Using Bukkit

**Note**: If you want to use events, you need to use `PlotSquared-BukkitAPI` as artifact id.

Let's imaging we want to have a flag defining a command, which is executed when someone enters a plot.

To get started, we're making sure PS is installed and correctly loaded.
This is what our main class could look like:
**(1)**
```java
package com.github.intellectualsites.example;

import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public class MyPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        // get P2's main class
        Plugin plotSquaredPlugin = getServer().getPluginManager().getPlugin("PlotSquared");
        if (plotSquaredPlugin != null && plotSquaredPlugin.isEnabled()) {
            getLogger().info("Found PS!");
            getServer().getPluginManager().registerEvents(new PlotEnterListener(), this);
        } else {
            getLogger().warning("PS not found. Continuing...");
        }
        // do other onEnable stuff
    }
}
```
This way, you can check if the plugin is installed and enabled. Please note, that you should use either
`depend` or `softdepend` in your plugin.yml. 

**Note**: It's recommended to disable the plugin if a required dependency is missing. Also, the main class must not initialize any PlotSquared-class directly, otherwise an error will be thrown on startup.

Now, there is a new class which we need to create before this code works. This is how our listener looks like:
**(2)**
```java
package com.github.intellectualsites.example;

import com.github.intellectualsites.plotsquared.bukkit.events.PlayerEnterPlotEvent;
import com.github.intellectualsites.plotsquared.plot.object.Plot;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

import java.util.Optional;

public class PlotEnterListener implements Listener {
    private final CommandFlag commandFlag;

    public PlotEnterListener() {
        PlotAPI api = new PlotAPI();
        // create and register new flag
        this.commandFlag = new CommandFlag("command");
        api.addFlag(commandFlag);
    }

    @EventHandler
    public void onPlotEnter(PlayerEnterPlotEvent event) {
        Plot plot = event.getPlot();
        Optional<CommandValue> flagValue = plot.getFlag(commandFlag);
        flagValue.ifPresent(command -> {
            String commandString = command.getCommandString();
            boolean asConsole = command.isAsConsole();
            Bukkit.dispatchCommand(asConsole ? Bukkit.getConsoleSender() : event.getPlayer(), commandString);
        });
    }
}
```

We're seeing 2 new classes here. The first one is our custom flag:
**(3)**
```java
package com.github.intellectualsites.example;

import com.github.intellectualsites.plotsquared.plot.flag.Flag;

public class CommandFlag extends Flag<CommandValue> {

    public CommandFlag(String name) {
        super(name);
    }

    @Override
    public String valueToString(Object o) {
        return o.toString();
    }

    @Override
    public CommandValue parseValue(String s) {
        return CommandValue.fromString(s);
    }

    @Override
    public String getValueDescription() {
        return "Flag must be in the format '<your command here>;;<true|false>'";
    }
}
```
we mainly define the conversion between a string and our `CommandValue` here. Our `CommandValue` class, the other new one, looks like this:
**(4)**
```java
package com.github.intellectualsites.example;

public class CommandValue {
    private final String commandString;
    private final boolean asConsole;

    private CommandValue(String commandString, boolean asConsole) {
        this.commandString = commandString;
        this.asConsole = asConsole;
    }

    public static CommandValue fromString(String s) {
        String[] split = s.split(";;");
        if (split.length != 2) {
            return null;
        }
        boolean asConsole = "true".equalsIgnoreCase(split[1]);
        // as PS doesn't allow spaces in the command, we need this little workaround
        return new CommandValue(split[0].replace('_', ' '), asConsole);
    }

    @Override
    public String toString() {
        return commandString + ";;" + asConsole;
    }
}
```
That's it.

Now, this plugin installed, we can run `/plot flag set command plot_info;;false` when standing on a claimed plot.
Afterwards, when a player enters that plot, the info will shown (if they're permitted to).

## Adding custom flags in PlotSquared <= 1.12

**Note**: This section won't be updated.

``` java
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import com.intellectualcrafters.plot.AbstractFlag;
import com.intellectualcrafters.plot.Flag;
import com.intellectualcrafters.plot.Plot;
import com.intellectualcrafters.plot.api.PlotAPI;
import com.intellectualcrafters.plot.events.PlayerEnterPlotEvent;

public class Main extends JavaPlugin implements Listener {
    PlotAPI plotAPI = null;
    @Override
    public void onEnable() {

        // Get the plugin!
        Plugin plotSquaredPlugin = getServer().getPluginManager().getPlugin("PlotSquared");

        // Checking if PlotSquared is enabled
        if (plotSquaredPlugin!=null && plotSquaredPlugin.isEnabled()) {

            // Here we are getting the plotAPI class which allows us to do a lot of cool things
            plotAPI = new PlotAPI((JavaPlugin) plotSquaredPlugin);
        }
        else {

            // Oh no! PlotSquared is not enabled. As an example, let's send a message to console and disable the plugin.
            // Of course you could move all the PlotSquared related code into another class so you won't have to disable the plugin.
            getServer().getConsoleSender().sendMessage("Plugin 'PlotSquared' not found. Disabling MyPlugin");
            Bukkit.getPluginManager().disablePlugin(this);
        }

        // Adding an AbstractFlag (the key for the flag)
        AbstractFlag abFlag = new AbstractFlag("greeting") {
            
            // The following stuff here is only optional, and allows you to restrict what users can set in the flags:
            
            @Override
            public String parseValue(String value) {
                
                // Only accept woof, dog, cat, meow for the greeting flag
                                
                switch (value.toLowerCase()) {
                    case "woof":
                    case "dog":
                        return "dog"; 
                    case "cat":
                    case "meow":
                        return "cat";
                    default:
                        return null; // Return null the value is invalid
                }
                
                // You could also use a simple if statement e.g.
                
                /*
                if (value.equals("hello")) {
                    return value;
                }
                return null;
                */
            }
            
            
            @Override
            public String getValueDesc() {
                return "You are currently only allowed to set the greeting to: woof, dog, cat, meow"; 
            }
        };
        // We need to now register the flag, as well as the default value ""
        plotAPI.addFlag(abFlag);

        // Don't forget to register your events so you can send players a greeting message!
        getServer().getPluginManager().registerEvents(this, this);
    }

    // Here is the PlayerEnterPlotEvent, there are loads of other events you can hook into, which will be documented on the site.
    @EventHandler
    public void onPlayerEnterPlot(PlayerEnterPlotEvent event) {
        Plot plot = event.getPlot();
        Player player = event.getPlayer();

        // checking if the plot has that flag
        if (plot.settings.getFlag("greeting")!=null) {

            // Get the message
            String message = plot.settings.getFlag("greeting").getValue();

            // Only send a message if it's not blank.
            if (!message.equals("")) {

                // Send the player the message set for that plot
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', message));
            }
        }
    }
}
```
