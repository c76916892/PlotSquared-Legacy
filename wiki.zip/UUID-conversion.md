﻿## Overview
This was added in version 2.10. UUID conversion allows you to switch between different methods of UUID storage on your server. 

## Modes
#### offline
Will use the same UUID as an offline-mode server. i.e. The UUID will be based on the playername (case sensitive)
#### lower
Offline mode but case insensitive, as it gets the UUID from the lowercase username.
#### online
Use online-mode UUID provided by mojang. This mode will not work properly if you are using a pre-UUID version of Bukkit, or your server is set to offline mode.

## Usage
A command is required to be executed in order to convert. You are urged to backup your database before conversion, as plots may be lost if something goes wrong:
`/plot uuidconvert <mode>`
