﻿#### [Developer API](https://github.com/IntellectualSites/PlotSquared/wiki/API-Documentation)
### Overview
 - Scripts go in the `PlotSquared/scripts` folder
 - The language is Javascript

### Commands
 - `/plot debugexec run <script> [args...]`    
 - `/plot debugexec runasync <script> [args...]`    
 - `/plot debugexec <code goes here>`    

### Example scripts
 - [[Merging-all-plots]] (included with P^2)
 - [[Setting-all-signs]]
 - [[Fix-plot-borders]]
 - [[Resetting-plot-biomes]]
 - [[Allowing-a-player-to-claim-more-plots]]
 - [[Printing-the-furthest-plot]]
 - [[Startup-script-commands]]

##### Have a script of your own? Feel free to add it to this page or create a ticket and we can add it: https://github.com/IntellectualSites/PlotSquared/issues
