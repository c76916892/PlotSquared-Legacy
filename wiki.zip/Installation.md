﻿## Initial Setup:
- [Download the plugin](https://www.spigotmc.org/resources/plotsquared.1177/)
- Put "PlotSquared-Bukkit-4.x.jar" into your `plugins` folder on your server.
- Run the server once to generate the necessary files.

## Database Configuration

### Database: SQLite
If you do not have a MySQL database, storage will be automatically set to SQLite and you may skip this step.

### Database: MySQL
**Please remember that you can use MySQL or SQLite, but not both at the same time.**    
**Also note that you can convert to MySQL at any time using the `/plot database` command.**    
**Enabling MySQL also supports other storage types like MariaDB.**    
- Navigate to `/plugins/PlotSquared/config/storage.yml`
- Configure the settings for your MySQL database

#### Create a new Plot world
You can create a plotworld using the setup wizard. Use `/plot setup` to start the wizard.    
Every step requires the command, e.g. `/plot set PlotSquared` and replace "PlotSquared" with your desired value.
If you are done, PlotSquared will teleport you to the generated plotworld.

#### Switching Generators
Sometimes PlotSquared will be unable to switch the generators for your plot worlds. If this is the case, you will need to manually switch the generator over while the server is stopped. Check the bukkit.yml and change the generator while the server is stopped using the following format:
```yaml
worlds:
  plotworld:
    generator: PlotSquared
```
Replace `plotworld` with the name of your plotworld.

#### Commands and Permissions
[Main Commands](https://github.com/IntellectualSites/PlotSquared/wiki/Commands)    
[Permission Packs](https://github.com/IntellectualSites/PlotSquared/wiki/Permission-Packs)    
[Administrative Permissions](https://github.com/IntellectualSites/PlotSquared/wiki/Bypass-Permissions)    

#### Setup PlotSquared as default world
This is required if the DEFAULT world (as defined in server.properties) should be set to PlotSquared, click [here](https://github.com/IntellectualSites/PlotSquared/wiki/Set-a-plotworld-as-default-world) to learn how to setup PlotSquared as default world.

## Adding Road Schematics
### Road schematics are added after world generation. You are also capable of changing the roads whenever you want, however newly created roads are recommended.
First you want to build a road surrounding your plot. The road includes the walls and the full intersection. Therefore you have to build over the intersections as well, we recommend going 3 or 4 blocks ahead.

Here is a link of the parts of a road schematic you have to create. The pink parts are just a recommendation, but the past has shown us that it's good to add them before creating the road schematic:
![Road schematic](https://i.imgur.com/ISPEJPC.png)

Once you have created the road, stand in the plot and execute the following command:

`/plot createroadschematic`

To test the schematic (recommended), stand in some other road not part of the schematic. The following will regenerate the road in the chunk you are standing in:
 - Road schematics are stored in plugins/PlotSquared/schematics/GEN_ROAD_SCHEMATIC/`world`
 - Once creating a road schem, it can be **copied** to a new `world` folder in this directory, providing the schematic for generating a new world. 

`/plot debugroadregen plot`

If all is well, you can begin regenerating the roads in the entire map. Open up your console and execute the following command (this may take a while / also causes lag spikes):

`/plot regenallroads <world> [height]`
 - The height option, if specified, changes the amount of air to paste above the schematic.    
