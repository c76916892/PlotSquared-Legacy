﻿If plotsquared won't recognize your plotworld you should add this to the bottom of your bukkit.yml file:

```
worlds:
  plotworld:
    generator: PlotSquared
```
