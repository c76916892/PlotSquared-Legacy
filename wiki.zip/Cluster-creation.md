﻿## This guide is for PlotSquared versions <= 1.12.2
The following in a excerpt from the Augmented plotworld installation guide. If you would like a partial plotworld rather than a full plot world, please see the [guide](https://github.com/IntellectualCrafters/PlotSquared/wiki/Augmented-Plot-Worlds)

*Please enable clusters on your PlotSquared config.

# Step 3: Creating a cluster
Cluster creation can be somewhat tricky to understand the first time. The clusters work by a co-ordinate system much like a normal plotworld, and each cluster will be created between two points in this co-ordinate system.

Please login and travel to your new cluster world. The following command will be used to create a cluster:
`/plot cluster create <name> <plot id 1> <plot id 2>`

`name`: what you want to call the cluster

`plot id 1`: Is the first co-ordinate and must be smaller than `plot id 2`
The id comes in the form `X;Z` e.g. `5;3`

To calculate what the plot id would be for a location use the following formula:
big `X'` and `Z'` represents the plot X and Z value respectively
small `x` and `z` represents the minecraft x and z value respectively
```
`X' = 1 + (x / <plot_width + road_width>)`
`Z' = 1 + (z / <plot_width + road_width>)`
```
 - You can find your plot width and road width within the `worlds.yml`

#### Notes
Just entering `/plot cluster create` will display an estimate for your current plot id.
