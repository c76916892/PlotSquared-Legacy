﻿## Admin bypass permissions
### Event bypass
### Bypass destroy and build needs "plots.admin.interact.other" to function.    

 - plots.admin.build.road
 - plots.admin.build.unowned
 - plots.admin.build.other
 - plots.admin.destroy.road
 - plots.admin.destroy.unowned
 - plots.admin.destroy.other
 - plots.admin.destroy.groundlevel
 - plots.admin.interact.road
 - plots.admin.interact.unowned
 - plots.admin.interact.other
 - plots.admin.vehicle.break.road
 - plots.admin.vehicle.break.unowned
 - plots.admin.vehicle.break.other
 - plots.admin.projectile.road
 - plots.admin.projectile.unowned
 - plots.admin.projectile.other
 - plots.admin.pve.road
 - plots.admin.pve.unowned
 - plots.admin.pve.other
 - plots.admin.entry.denied

### Command bypass
 - plots.admin.command.schematic
 - plots.admin.command.schematic.paste
 - plots.admin.command.schematic.save
 - plots.admin.command.clear
 - plots.admin.command.continue
 - plots.admin.command.add
 - plots.admin.command.deny
 - plots.admin.command.done
 - plots.admin.command.kick
 - plots.admin.command.merge
 - plots.admin.command.reload
 - plots.admin.command.load
 - plots.admin.command.download
 - plots.admin.command.chat
 - plots.admin.command.save
 - plots.admin.command.set
 - plots.admin.command.setowner
 - plots.admin.command.setup
 - plots.admin.command.swap
 - plots.admin.command.trust
 - plots.admin.command.untrust
 - plots.admin.command.unlink
 - plots.admin.command.update
 - plots.admin.command.delete
 - plots.admin.command.autoclear
 - plots.admin.command.remove
 - plots.admin.command.blocked-cmds.shared
 - plots.admin.command.blocked-cmds.other

### Flag bypass
 - plots.flag.notify-leave.bypass
 - plots.flag.notify-enter.bypass
 - plots.gamemode.bypass

### Misc bypasses
 - plots.teleport.delay.bypass
