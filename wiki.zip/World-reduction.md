﻿## Drastically reduce the size of your plotworld
#### World border
To prevent continued exploration, the world border can be enabled in each plotworld. The option can be found in the `worlds.yml` at `worlds.<world>.world.border`

The world border is based on the furthest plot from the origin (0,0) and will prevent chunks from being loaded outside this region.

If you already have plots which are far away from the origin, the world border will not be very effective. You may wish to use the condense function (see below).
#### Plot expiry:
In the `settings.yml` look for the following section
```YML
enabled-components:
  plot-expiry: false
```
```YML
# This is an auto clearing task called `task1`
auto-clear:
  task1:
    threshold: 1
    required-plots: -1
    confirmation: true
    days: 7
    worlds: 
    - "*"
    # See: https://github.com/IntellectualSites/PlotSquared/wiki/Plot-analysis
    calibration:
      variety: 0
      variety-sd: 0
      changes: 0
      changes-sd: 1
      faces: 0
      faces-sd: 0
      data-sd: 0
      air: 0
      air-sd: 0
      data: 0
```
To enable ExpireManager, set 'enabled' to true, and set the expiry delay in days. This clears and deletes plots where the owner has been inactive (i.e. not logged on) for the amount of days specified.

For more advanced plot clearing, see the plot analysis page:
https://github.com/IntellectualSites/PlotSquared/wiki/Plot-analysis
#### Plot condensation (Added in 2.7.5) (intensive)
__This task is great in conjunction with the world trim function (see below)__
This will move any plots outside a specified radius nearer to the origin (0,0). 
To check how many plots are outside a radius: `/plot condense <world> info <radius>`
 - It will also display the minimum radius you can specify.
 - If you already have thousands of plots outside your desired radius, it can take quite a long time.

To run the task use: `/plot condense <world> start <radius>`

#### World trim (intensive)
The world trim function will attempt to delete as many chunks which contain no plots. It will drastically reduce the size of the world on disk. It is an intensive task, so it is recommended to run it only every week or so.

To run the task use: `/plot trim <world>`

For world auto-trimming, see here:
https://github.com/IntellectualSites/PlotSquared/wiki/Chunk-processor
