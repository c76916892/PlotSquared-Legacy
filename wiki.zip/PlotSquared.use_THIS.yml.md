﻿## The file is located at `/plugins/PlotSquared/translations/PlotSquared.use_THIS.yml`

In version 5+, PlaceholderAPI placeholders may be used in these captions. See [this](https://github.com/IntellectualSites/PlotSquared/wiki/Placeholders#use-placeholderapi-placeholders-in-plotsquared) link for more information.

```yaml
confirm:
  expired_confirm: $2Confirmation has expired, please run the command again!
  failed_confirm: $2You have no pending actions to confirm!
  requires_confirm: '$2Are you sure you wish to execute: $1%s$2?&-$2This cannot be
    undone! If you are sure: $1/plot confirm'
move:
  move_success: $4Successfully moved plot.
  copy_success: $4Successfully copied plot.
  requires_unowned: $2The location specified is already occupied.
debug:
  requires_unmerged: $2The plot cannot be merged
  debug_header: $1Debug Information&-
  debug_section: $2>> $1&l%val%
  debug_line: $2>> $1%var%$2:$1 %val%&-
set:
  set_attribute: $4Successfully set %s0 set to %s1
web:
  generating_link: $1Processing plot...
  generating_link_failed: $2Failed to generate download link!
  save_failed: $2Failed to save
  load_null: $2Please use $4/plot load $2to get a list of schematics
  load_failed: $2Failed to load schematic
  load_list: '$2To load a schematic, use $1/plot load #'
  save_success: $1Successfully saved!
compass:
  compass_target: $4Successfully targeted plot with compass
cluster:
  cluster_available_args: '$1The following sub commands are available: $4list$2, $4create$2,
    $4delete$2, $4resize$2, $4invite$2, $4kick$2, $4leave$2, $4members$2, $4info$2,
    $4tp$2, $4sethome'
  cluster_list_heading: $2There are $1%s$2 clusters in this world
  cluster_list_element: $2 - $1%s&-
  cluster_intersection: '$2The proposed area overlaps with: %s0'
  cluster_outside: '$2The proposed area is outside the plot area: %s0'
  cluster_added: $4Successfully created the cluster.
  cluster_deleted: $4Successfully deleted the cluster.
  cluster_resized: $4Successfully resized the cluster.
  cluster_added_user: $4Successfully added user to the cluster.
  cannot_kick_player: $2You cannot kick that player
  cluster_invited: '$1You have been invited to the following cluster: $2%s'
  cluster_removed: '$1You have been removed from cluster: $2%s'
  cluster_kicked_user: $4Successfully kicked the user
  invalid_cluster: '$1Invalid cluster name: $2%s'
  cluster_not_added: $2That player was not added to the plot cluster
  cluster_cannot_leave: $1You must delete or transfer ownership before leaving
  cluster_added_helper: $4Successfully added a helper to the cluster
  cluster_removed_helper: $4Successfully removed a helper from the cluster
  cluster_regenerated: $4Successfully started cluster regeneration
  cluster_teleporting: $4Teleporting...
  cluster_info: '$1Current cluster: $2%id%&-$1Name: $2%name%&-$1Owner: $2%owner%&-$1Size:
    $2%size%&-$1Rights: $2%rights%'
border:
  border: $2You are outside the current map border
worldedit masks:
  worldedit_bypass: $2&oTo bypass your restrictions use $4/plot wea
  worldedit_bypassed: $2Currently bypassing WorldEdit restriction.
gamemode:
  gamemode_was_bypassed: $1You bypassed the GameMode ($2{gamemode}$1) $1set for $2{plot}
height limit:
  height_limit: $1This plot area has a height limit of $2{limit}
records:
  notify_enter: $2%player $2entered your plot ($1%plot$2)
  notify_leave: $2%player $2left your plot ($1%plot$2)
swap:
  swap_overlap: $2The proposed areas are not allowed to overlap
  swap_dimensions: $2The proposed areas must have comparable dimensions
  swap_syntax: $2/plot swap <id>
  swap_success: $4Successfully swapped plots
comment:
  inbox_notification: '%s unread messages. Use /plot inbox'
  not_valid_inbox_index: $2No comment at index %s
  inbox_item: $2 - $4%s
  comment_syntax: $2Use /plot comment [X;Z] <%s> <comment>
  invalid_inbox: '$2That is not a valid inbox.&-$1Accepted values: %s'
  no_perm_inbox: $2You do not have permission for that inbox
  no_perm_inbox_modify: $2You do not have permission to modify that inbox
  no_plot_inbox: $2You must stand in or supply a plot argument
  comment_removed_success: $4Successfully deleted comment/s:n$2 - '$3%s$2'
  comment_removed_failure: $4Failed to delete comment!
  comment_added: $4A comment has been left
  comment_header: $2&m---------&r $1Comments $2&m---------&r
  inbox_empty: $2No comments
console:
  not_console: $2For safety reasons, this command can only be executed by console.
  is_console: $2This command can only be executed by a player.
clipboard:
  paste_failed: '$2Failed to paste the selection. Reason: $2%s'
toggle:
  toggle_enabled: '$2Enabled setting: %s'
  toggle_disabled: '$2Disabled setting: %s'
blocked command:
  command_blocked: $2That command is not allowed in this plot
done:
  done_already_done: $2This plot is already marked as done
  done_not_done: $2This plot is not marked as done.
  done_insufficient_complexity: $2This plot is too simple. Please add more detail
    before using this command.
  done_success: $1Successfully marked this plot as done.
  done_removed: $1You may now continue building in this plot.
ratings:
  ratings_purged: $2Purged ratings for this plot
  rating_not_valid: $2You need to specify a number between 1 and 10
  rating_already_exists: $2You have already rated plot $2%s
  rating_applied: $4You successfully rated plot $2%s
  rating_disliked: $4You successfully disliked plot $2%s
  rating_liked: $4You successfully liked plot $2%s
  rating_not_your_own: $2You cannot rate your own plot
  rating_not_done: $2You can only rate finished plots.
  rating_not_owned: $2You cannot rate a plot that is not claimed by anyone
tutorial:
  rate_this: $2Rate this plot!
  comment_this: '$2Leave some feedback on this plot: %s'
economy:
  econ_disabled: $2Economy is not enabled
  cannot_afford_plot: $2You cannot afford to buy this plot. It costs $1%s
  not_for_sale: $2This plot is not for sale
  cannot_buy_own: $2You cannot buy your own plot
  plot_sold: $4Your plot; $1%s0$4, has been sold to $1%s1$4 for $1$%s2
  cannot_afford_merge: $2You cannot afford to merge the plots. It costs $1%s
  added_balance: $1%s $2has been added to your balance
  removed_balance: $1%s $2has been taken from your balance
  removed_granted_plot: $2You used %s plot grant(s), you've got $1%s $2left
setup:
  setup_init: '$1Usage: $2/plot setup <value>'
  setup_step: '$3[$1Step %s0$3] $1%s1 $2- $1Expecting: $2%s2 $1Default: $2%s3'
  setup_invalid_arg: '$2%s0 is not a valid argument for step %s1. To cancel setup
    use: $1/plot setup cancel'
  setup_valid_arg: $2Value $1%s0 $2set to %s1
  setup_finished: $4You should have been teleported to the created world. Otherwise
    you will need to set the generator manually using the bukkit.yml or your chosen
    world management plugin.
  setup_world_taken: $2%s is already a world
  setup_missing_world: $2You need to specify a world name ($1/plot setup &l<world>$1
    <generator>$2)&-$1Additional commands:&-$2 - $1/plot setup <value>&-$2 - $1/plot
    setup back&-$2 - $1/plot setup cancel
  setup_missing_generator: $2You need to specify a generator ($1/plot setup <world>
    &l<generator>&r$2)&-$1Additional commands:&-$2 - $1/plot setup <value>&-$2 - $1/plot
    setup back&-$2 - $1/plot setup cancel
  setup_invalid_generator: '$2Invalid generator. Possible options: %s'
schematics:
  schematic_too_large: $2The plot is too large for this action!
  schematic_missing_arg: '$2You need to specify an argument. Possible values: $1save$2,
    $1paste $2, $1exportall$2, $1list'
  schematic_invalid: '$2That is not a valid schematic. Reason: $2%s'
  schematic_valid: $2That is a valid schematic
  schematic_paste_failed: $2Failed to paste the schematic
  schematic_paste_success: $4The schematic pasted successfully
  schematic_list: '$4Saved Schematics: $1%s'
  schematic_road_created: $1Saved new road schematic. To test the schematic, fly to
    a few other plots and run /plot debugroadregen
  mca_file_size: '$1Note: The `.mca` files are 512x512'
  schematic_exportall_started: $1Starting export...
  schematic_exportall_world_args: $1Need world argument. Use $3/plot sch exportall
    <area>
  schematic_exportall_mass_started: $1Schematic mass export has been started. This
    may take a while
  schematic_exportall_count: $1Found $3%s $1plots...
  schematic_exportall_finished: $1Finished mass export
  schematic_exportall_single_finished: $1Finished export
schematic:
  schematic_exportall_world: $1Invalid world. Use &3/plot sch exportall <area>
error:
  task_in_process: $1Task is already running.
titles:
  title_entered_plot: '$1Plot: %world%;%x%;%z%'
  title_entered_plot_sub: $4Owned by %s
  prefix_greeting: '$1%id%$2> '
  prefix_farewell: '$1%id%$2> '
core:
  prefix: $3[$1P2$3] $2
  enabled: $1%s0 is now enabled
reload:
  reloaded_configs: $1Translations and world settings have been reloaded
  reload_failed: $2Failed to reload file configurations
desc:
  desc_set: $2Plot description set
  desc_unset: $2Plot description unset
alias:
  alias_set_to: $2Plot alias set to $1%alias%
  alias_removed: $2Plot alias removed
  alias_too_long: $2The alias must be < 50 characters in length
  alias_is_taken: $2That alias is already taken
position:
  position_set: $1Home position set to your current location
  position_unset: $1Home position reset to the default location
  home_argument: $2Use /plot set home [none]
permission:
  no_schematic_permission: $2You don't have the permission required to use schematic
    $1%s
  no_permission: '$2You are lacking the permission node: $1%s'
  no_permission_event: '$2You are lacking the permission node: $1%s'
  no_plot_perms: $2You must be the plot owner to perform this action
  cant_claim_more_plots: $2You can't claim more plots.
  cant_claim_more_clusters: $2You can't claim more clusters.
  cant_transfer_more_plots: $2You can't send more plots to that user
  cant_claim_more_plots_num: $2You can't claim more than $1%s $2plots at once
  merge_request_confirm: Merge request from %s
merge:
  merge_not_valid: $2This merge request is no longer valid.
  merge_accepted: $2The merge request has been accepted
  success_merge: $2Plots have been merged!
  merge_requested: $2Successfully sent a merge request
  no_perm_merge: '$2You are not the owner of the plot: $1%plot%'
  no_available_automerge: $2You do not own any adjacent plots in the specified direction
    or are not allowed to merge to the required size.
  unlink_impossible: $2You can only unlink a mega-plot
  unmerge_cancelled: $1Unlink has been cancelled
  unlink_success: $2Successfully unlinked plots.
commandconfig:
  not_valid_subcommand: $2That is not a valid subcommand
  did_you_mean: '$2Did you mean: $1%s'
  subcommand_set_options_header: '$2Possible Values: '
  command_syntax: '$1Usage: $2%s'
  flag_tutorial_usage: '$1Have an admin set the flag: $2%s'
errors:
  invalid_player: '$2Player not found: $1%s$2.'
  invalid_player_offline: '$2The player must be online: $1%s.'
  invalid_command_flag: '$2Invalid command flag: %s0'
  error: '$2An error occurred: %s'
  command_went_wrong: $2Something went wrong when executing that command...
  no_free_plots: $2There are no free plots available
  not_in_plot: $2You're not in a plot
  not_loaded: $2The plot could not be loaded
  not_in_cluster: $2You must be within a plot cluster to perform that action
  not_in_plot_world: $2You're not in a plot area
  plotworld_incompatible: $2The two worlds must be compatible
  not_valid_world: $2That is not a valid world (case sensitive)
  not_valid_plot_world: $2That is not a valid plot area (case sensitive)
  no_plots: $2You don't have any plots
  wait_for_timer: $2A set block timer is bound to either the current plot or you.
    Please wait for it to finish
paste:
  debug_report_created: '$1Uploaded a full debug to: $1%url%'
purge:
  purge_success: $4Successfully purged %s plots
trim:
  trim_in_progress: A world trim task is already in progress!
block list:
  block_list_separator: '$1,$2 '
biome:
  need_biome: $2You need to specify a valid biome.
  biome_set_to: $2Plot biome set to $2
teleport:
  teleported_to_plot: $1You have been teleported
  teleported_to_road: $2You got teleported to the road
  teleport_in_seconds: $1Teleporting in %s seconds. Do not move...
  teleport_failed: $2Teleportation cancelled due to movement or damage
set block:
  set_block_action_finished: $1The last setblock action is now finished.
unsafe:
  debugallowunsafe_on: $2Unsafe actions allowed
  debugallowunsafe_off: $2Unsafe actions disabled
invalid:
  not_valid_block: '$2That''s not a valid block: %s'
  not_allowed_block: '$2That block is not allowed: %s'
  not_valid_number: '$2That''s not a valid number within the range: %s'
  not_valid_plot_id: $2That's not a valid plot id.
  found_no_plots: $2Found no plots with your search query
  number_not_in_range: 'That''s not a valid number within the range: (%s, %s)'
  number_not_positive: 'That''s not a positive number: %s'
  not_a_number: '%s is not a valid number.'
need:
  need_block: $2You've got to specify a block
near:
  plot_near: '$1Players: %s0'
info:
  none: ' None'
  now: Now
  never: Never
  unknown: Unknown
  server: Server
  everyone: Everyone
  plot_unowned: $2The current plot must have an owner to perform this action
  plot_info_unclaimed: $2Plot $1%s$2 is not yet claimed
  plot_info_header: $3&m---------&r $1INFO $3&m---------
  plot_info_hidden: $2You cannot view the information about this plot
  plot_info_format: '$1ID: $2%id%$1&-$1Area: $2%area%$1&-$1Alias:$2%alias%$1&-$1Owner:$2%owner%$1&-$1Biome:
    $2%biome%$1&-$1Can Build: $2%build%$1&-$1Rating: $2%rating%&-$1Seen: $2%seen%&-$1Trusted:$2%trusted%$1&-$1Members:$2%members%$1&-$1Denied:$2%denied%$1&-$1Flags:$2%flags%&-$1Description:
    $2%desc%$1'
  plot_info_footer: $3&m---------&r $1INFO $3&m---------
  plot_info_trusted: $1Trusted:$2%trusted%
  plot_info_members: $1Members:$2%members%
  plot_info_denied: $1Denied:$2%denied%
  plot_info_flags: $1Flags:$2 %flags%
  plot_info_biome: $1Biome:$2 %biome%
  plot_info_rating: $1Rating:$2 %rating%
  plot_info_likes: $1Like Ratio:$2 %likes%%
  plot_info_owner: $1Owner:$2%owner%
  plot_info_id: $1ID:$2 %id%
  plot_info_alias: $1Alias:$2 %alias%
  plot_info_size: $1Size:$2 %size%
  plot_info_seen: $1Seen:$2 %seen%
  plot_user_list: ' $1%user%$2,'
  plot_flag_list: $2%s0:%s1$3
  plot_no_description: No description set.
  info_syntax_console: $2/plot info X;Z
working:
  generating_component: $1Started generating component from your settings
  clearing_done: $4Clear completed! Took %sms.
  deleting_done: $4Delete completed! Took %sms.
  plot_not_claimed: $2Plot not claimed
  plot_is_claimed: $2This plot is already claimed
  claimed: $4You successfully claimed the plot
list:
  comment_list_header_paged: $2(Page $1%cur$2/$1%max$2) $1List of %amount% comments
  clickable: ' (interactive)'
  area_list_header_paged: $2(Page $1%cur$2/$1%max$2) $1List of %amount% areas
  plot_list_header_paged: $2(Page $1%cur$2/$1%max$2) $1List of %amount% plots
  plot_list_header: $1List of %word% plots
  plot_list_item: $2>> $1%id$2:$1%world $2- $1%owner
  plot_list_item_ordered: $2[$1%in$2] >> $1%id$2:$1%world $2- $1%owner
  plot_list_footer: $2>> $1%word% a total of $2%num% $1claimed %plot%.
chat:
  plot_chat_spy_format: '$2[$1Plot Spy$2][$1%plot_id%$2] $1%sender%$2: $1%msg%'
  plot_chat_format: '$2[$1Plot Chat$2][$1%plot_id%$2] $1%sender%$2: $1%msg%'
  plot_chat_forced: $2This world forces everyone to use plot chat.
  plot_chat_on: $4Plot chat enabled.
  plot_chat_off: $4Plot chat disabled.
deny:
  denied_added: $4You successfully denied the player from this plot
  denied_need_argument: $2Arguments are missing. $1/plot denied add <name> $2or $1/plot
    denied remove <name>
  was_not_denied: $2That player was not denied on this plot
  you_got_denied: $4You are denied from the plot you were previously on, and got teleported
    to spawn
  cant_remove_owner: $2You can't remove the plot owner
kick:
  you_got_kicked: $4You got kicked!
flag:
  flag_key: '$2Key: %s'
  flag_type: '$2Type: %s'
  flag_desc: '$2Desc: %s'
  not_valid_flag: $2That is not a valid flag
  not_valid_flag_suggested: '$2That is not a valid flag. Did you mean: $1%s'
  not_valid_value: $2Flag values must be alphanumerical
  flag_not_removed: $2The flag could not be removed
  flag_not_added: $2The flag could not be added
  flag_removed: $4Successfully removed flag
  flag_partially_removed: $4Successfully removed flag value(s)
  flag_added: $4Successfully added flag
  flag_list_entry: '$2%s: $1%s'
  flag_list_see_info: Click to view information about the flag
  flag_parse_exception: '$2Failed to parse flag ''%s'', value ''%s'': %s'
  flag_info_header: $3&m---------&r $1Plot² Flags $3&m---------
  flag_info_footer: $3&m---------&r $1Plot² Flags $3&m---------
  flag_info_color_key: $1
  flag_info_color_value: $2
  flag_info_name: 'Name: '
  flag_info_category: 'Category: '
  flag_info_description: 'Description: '
  flag_info_example: 'Example: '
  flag_info_default_value: 'Default Value: '
flags:
  flag_category_string: String Flags
  flag_category_integers: Integer Flags
  flag_category_doubles: Decimal Flags
  flag_category_teleport_deny: Teleport Deny Flag
  flag_category_string_list: String List Flags
  flag_category_weather: Weather Flags
  flag_category_music: Music Flags
  flag_category_block_list: Material Flags
  flag_category_intervals: Interval Flags
  flag_category_integer_list: Integer List Flags
  flag_category_gamemode: Game Mode Flags
  flag_category_enum: Generic Enum Flags
  flag_category_decimal: Decimal Flags
  flag_category_boolean: Boolean Flags
  flag_category_mixed: Mixed Value Flags
  flag_description_entity_cap: Set to an integer value to limit the amount of entities
    on the plot.
  flag_description_explosion: Set to `true` to enable explosions in the plot, and
    `false` to disable them.
  flag_description_music: Set to a music disk ID (item name) to play the music disc
    inside of the plot.
  flag_description_flight: Set to `true` to enable flight within the plot when in
    survival or adventure mode.
  flag_description_untrusted: Set to `false` to disallow untrusted players from visiting
    the plot.
  flag_description_deny_exit: Set to `true` to disallow players from exiting the plot.
  flag_description_description: Plot description. Supports '&' color codes.
  flag_description_greeting: Message sent to players on plot entry. Supports '&' color
    codes.
  flag_description_farewell: Message sent to players when leaving the plot. Supports
    '&' color codes.
  flag_description_weather: Specifies the weather conditions inside of the plot.
  flag_description_animal_attack: Set to `true` to allow animals to be attacked in
    the plot.
  flag_description_animal_cap: Set to an integer value to limit the amount of animals
    on the plot.
  flag_description_animal_interact: Set to `true` to allow animals to be interacted
    with in the plot.
  flag_description_block_burn: Set to `true` to allow blocks to burn within the plot.
  flag_description_block_ignition: Set to `false` to prevent blocks from igniting
    within the plot.
  flag_description_break: Define a list of materials players should be able to break
    even when they aren't added to the plot.
  flag_description_device_interact: Set to `true` to allow devices to be interacted
    with in the plot.
  flag_description_disable_physics: Set to `true` to disable block physics in the
    plot.
  flag_description_drop_protection: Set to `true` to prevent dropped items from being
    picked up by non-members of the plot.
  flag_description_feed: Specify an interval in seconds and an optional amount by
    which the players will be fed (amount is 1 by default).
  flag_description_forcefield: Set to `true` to enable member forcefield in the plot.
  flag_description_grass_grow: Set to `false` to prevent grass from growing within
    the plot.
  flag_description_hanging_break: Set to `true` to allow guests to break hanging objects
    in the plot.
  flag_description_hanging_place: Set to `true` to allow guests to hang objects in
    the plot.
  flag_description_heal: Specify an interval in seconds and an optional amount by
    which the players will be healed (amount is 1 by default).
  flag_description_hide_info: Set to `true` to hide plot information.
  flag_description_hostile_attack: Set to `true` to enable players to attack hostile
    mobs in the plot.
  flag_description_hostile_cap: Set to an integer value to limit the amount of hostile
    entities on the plot.
  flag_description_hostile_interact: Set to `true` to allow players to interact with
    hostile mobs in the plot.
  flag_description_ice_form: Set to `true` to allow ice to form in the plot.
  flag_description_ice_melt: Set to `false` to disable ice melting in the plot.
  flag_description_instabreak: Set to `true` to allow blocks to be instantaneously
    broken in survival mode.
  flag_description_invincible: Set to `true` to prevent players from taking damage
    inside of the plot.
  flag_description_item_drop: Set to `false` to prevent items from being dropped inside
    of the plot.
  flag_description_kelp_grow: Set to `false` to prevent kelp from growing in the plot.
  flag_description_liquid_flow: Set to `false` to disable liquids from flowing within
    the plot.
  flag_description_misc_break: Set to `true` to allow guests to break miscellaneous
    items.
  flag_description_misc_cap: Set to an integer value to limit the amount of miscellaneous
    entities on the plot.
  flag_description_misc_interact: Set to `true` to allow guests to interact with miscellaneous
    items.
  flag_description_misc_place: Set to `true` to allow guests to place miscellaneous
    items.
  flag_description_mob_break: Set to `true` to allow mobs to break blocks within the
    plot.
  flag_description_mob_cap: Set to an integer value to limit the amount of mobs on
    the plot.
  flag_description_mob_place: Set to `true` to allow mobs to place blocks within the
    plot.
  flag_description_mycel_grow: Set to `false` to prevent mycelium from growing in
    the plot.
  flag_description_notify_enter: Set to `true` to notify the plot owners when someone
    enters the plot.
  flag_description_notify_leave: Set to `true` to notify the plot owners when someone
    leaves the plot.
  flag_description_no_worldedit: Set to `true` to disable WorldEdit usage within the
    plot.
  flag_description_place: Define a list of materials players should be able to place
    in the plot.
  flag_description_player_interact: Set to `true` to allow guests to interact with
    players in the plot.
  flag_description_price: Set a price for a plot. Must be a positive decimal number.
  flag_description_pve: Set to `true` to enable PVE inside the plot.
  flag_description_pvp: Set to `true` to enable PVP inside the plot.
  flag_description_redstone: Set to `false` to disable redstone in the plot.
  flag_description_server_plot: Set to `true` to turn the plot into a server plot.
    This is equivalent to setting the server as the plot owner.
  flag_description_snow_form: Set to `true` to allow snow to form within the plot.
  flag_description_snow_melt: Set to `true` to allow snow to melt within the plot.
  flag_description_soil_dry: Set to `true` to allow soil to dry within the plot.
  flag_description_tamed_attack: Set to `true` to allow guests to attack tamed animals
    in the plot.
  flag_description_tamed_interact: Set to `true` to allow guests to interact with
    tamed animals in the plot.
  flag_description_time: Set the time in the plot to a fixed value.
  flag_description_titles: 'Set to `false` to disable plot titles. Can be set to:
    `none` (to inherit world settings), `true`, or `false`'
  flag_description_use: Define a list of materials players should be able to interact
    with in the plot.
  flag_description_vehicle_break: Set to `true` to allow guests to break vehicles
    in the plot.
  flag_description_vehicle_cap: Set to an integer value to limit the amount of vehicles
    on the plot.
  flag_description_vehicle_place: Set to `true` to allow guests to place vehicles
    in the plot.
  flag_description_vehicle_use: Set to `true` to allow guests to use vehicles in the
    plot.
  flag_description_villager_interact: Set to `true` to allow guests to interact with
    villagers in the plot.
  flag_description_vine_grow: Set to `false` to prevent vines from growing within
    the plot.
  flag_description_deny_teleport: 'Deny a certain group from teleporting to the plot.
    Available groups: members, nonmembers, trusted, nontrusted, nonowners'
  flag_description_gamemode: Determines the gamemode in the plot.
  flag_description_guest_gamemode: Determines the guest gamemode in the plot.
  flag_description_blocked_cmds: A list of commands that are blocked in the plot.
  flag_description_keep: 'Prevents the plot from expiring. Can be set to: true, false,
    the number of milliseconds to keep the plot for or a timestamp (3w 2d 5h).'
  flag_error_boolean: Flag value must be a boolean (true|false)
  flag_error_enum: 'Must be one of: %s'
  flag_error_gamemode: 'Flag value must be a gamemode: ''survival'', ''creative'',
    ''adventure'' or ''spectator.'
  flag_error_integer: Flag value must be a whole number
  flag_error_integer_list: Flag value must be an integer list
  flag_error_interval: Value(s) must be numeric. /plot set flag <flag> <interval>
    [amount]
  flag_error_keep: Flag value must be a timestamp or a boolean
  flag_error_long: Flag value must be a whole number (large numbers allowed)
  flag_error_plotblocklist: Flag value must be a block list
  flag_error_invalid_block: The provided value is not a valid block
  flag_error_double: Flag value must be a decimal number.
  flag_error_string: Flag value must be alphanumeric. Some special characters are
    allowed.
  flag_error_stringlist: Flag value must be a string list
  flag_error_weather: 'Flag must be a weather: ''rain'' or ''sun'''
  flag_error_music: Flag value must be a valid music disc ID.
trusted:
  trusted_added: $4You successfully trusted a user to the plot
  was_not_added: $2That player was not trusted on this plot
  plot_removed_user: $1Plot %s of which you were added to has been deleted due to
    owner inactivity
member:
  removed_players: $2Removed %s players from this plot.
  plot_left: $2%s left the plot.
  already_owner: '$2That user is already the plot owner: %s0'
  already_added: '$2That user is already added to that category: %s0'
  member_added: $4That user can now build while the plot owner is online
  plot_max_members: $2You are not allowed to add any more players to this plot
  not_added_trusted: $2You must be added or trusted to the plot to run that command
owner:
  set_owner: $4You successfully set the plot owner
  set_owner_cancelled: $2The set owner action was cancelled
  set_owner_missing_player: '$1You need to specify a new owner. Correct usage is:
    $2/plot setowner <owner>'
  now_owner: $4You are now owner of plot %s
signs:
  owner_sign_line_1: '$1ID: $1%id%'
  owner_sign_line_2: '$1Owner:'
  owner_sign_line_3: $2%plr%
  owner_sign_line_4: $3Claimed
help:
  help_header: $3&m---------&r $1Plot² Help $3&m---------
  help_page_header: '$1Category: $2%category%$2,$1 Page: $2%current%$3/$2%max%$2'
  help_footer: $3&m---------&r $1Plot² Help $3&m---------
  help_info_item: $1/plot help %category% $3- $2%category_desc%
  help_item: $1%usage% [%alias%]&- $3- $2%desc%&-
  help_display_all_commands: Display all commands
  direction: '$1Current direction: %dir%'
generator_bucket:
  bucket_entries_ignored: $2Total bucket values add up to 1 or more. Blocks without
    a specified chance will be ignored
category:
  command_category_claiming: Claiming
  command_category_teleport: Teleport
  command_category_settings: Protection
  command_category_chat: Chat
  command_category_schematic: Web
  command_category_appearance: Cosmetic
  command_category_info: Info
  command_category_debug: Debug
  command_category_administration: Admin
grants:
  granted_plots: '$1Result: $2%s $1grants left'
  granted_plot: $1You granted %s0 plot to $2%s1
  granted_plot_failed: '$1Grant failed: $2%s'
legacyconfig:
  legacy_config_found: A legacy configuration file was detected. Conversion will be
    attempted.
  legacy_config_backup: A copy of worlds.yml $1have been saved in the file worlds.yml.old$1.
  legacy_config_replaced: '> %s has been replaced with %s'
  legacy_config_done: The conversion has finished. PlotSquared will now be disabled
    and the new configuration file will be used at next startup. Please review the
    new worlds.yml file. Please note that schematics will not be converted, as we
    are now using WorldEdit to handle schematics. You need to re-generate the schematics.
  legacy_config_conversion_failed: Failed to convert the legacy configuration file.
    See stack trace for information.
'-':
  custom_string: '-'
```
