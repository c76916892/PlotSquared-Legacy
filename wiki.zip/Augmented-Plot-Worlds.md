﻿## This guide is for PlotSquared versions <= 1.12.2
#### For full world augmentation, see [Here](https://github.com/IntellectualCrafters/PlotSquared/wiki/TerrainControl)

## Using the `/plot area` command. 
 - /plot area create ＜world＞:＜area name＞ type=2 terrain=? ＜modifiers＞
 - /plot area create pos1
 - /plot area create pos2
 - /plot confirm

Modifiers (optional):
 - size
 - gap
 - terrain (0 = flat, 1=flat + ores, 2=roads, 3=no change)
 - type (0 = standard, 1 = augmented full, 2 = augmented partial)
 - main
 - floor
 - wall
 - border

You can regenerate the entire area using:
`/plot area regen` (e.g. If you want to change the settings)

## Image
![http://i.imgur.com/hNymF10.jpg](http://i.imgur.com/stp4Gkx.png)

![https://i.imgur.com/JvW1vyw.png](https://i.imgur.com/JvW1vyw.png)
