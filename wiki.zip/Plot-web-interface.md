﻿### Setup
By default PlotSquared comes installed and configured to use the public web interface that we host. Downloads are anonymous, and it requires no setup on your end. 

### Disclaimer:
Metrics must be enabled. Any files you upload to the public web interface become public domain. If this is an issue you may host your own web interface.

### Setting up your own web interface:
Source: https://github.com/IntellectualSites/plotupload
Download: https://github.com/IntellectualSites/plotupload/archive/master.zip
Configuration section: `config/settings.yml`
``` yml
web:
  url: http://empcraft.com/plots/
  server-ip: your.ip.here
```

### Downloading:
`/plot download`    
This will generate a random key, and upload the file to the configured web server.

### Pasting a download
`/plot schematic paste url:<key>`    
Where `<key>` is the key generated from the download

### Saving
`/plot save`    

### Loading
`/plot load`

### Media:
https://youtu.be/w-0VushTSz4
