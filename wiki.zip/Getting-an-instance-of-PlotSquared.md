﻿``` java
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {
    public static Main THIS;

    @Override
    public void onEnable() {
        Main.THIS = this;
        if (Bukkit.getPluginManager().getPlugin("PlotSquared") != null) {
        // Do something
       }
    }
}
```
