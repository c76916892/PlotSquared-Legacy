﻿#### Plot plugin by Citymonstret & Empire92 & MBon29 & dordsor21 & NotMyFault
 - #### [`Discord`](https://discord.gg/KxkjDVg) | [`Spigot Forums`](https://www.spigotmc.org/threads/plotsquared.29970/)
 - [`Source`](https://github.com/IntellectualSites/PlotSquared-Legacy) | [`API Documentation`](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/API-Documentation)
 - #### [`Report an Issue`](https://github.com/IntellectualSites/PlotSquared-Legacy/issues/new/choose)
 - #### [`Suggest a Feature`](https://github.com/IntellectualSites/PlotSquared-Legacy/issues/new/choose)

***

# Wiki Links
## Installation
 - #### [`Initial Setup`](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Installation)  
 - #### [`Commands and Permissions`](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Commands)  
 - #### [`Administrative Permissions`](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Bypass-Permissions)  
###### Further installation
 - [Road schematics](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Installation#adding-road-schematics)  
 - [settings.yml](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/settings.yml)    
 - [commands.yml](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/commands.yml)    
 - [worlds.yml](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/worlds.yml)    
 - [UUID conversion](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/UUID-conversion)
 - [Set a plot world as default world](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Set-a-plotworld-as-default-world)         
 - [ChestShop Compatibility](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/ChestShop-Compatibility)
#### Usage
###### Customization
 - [Translation](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/PlotSquared.use_THIS.yml)  
 - [Command aliases](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/aliases)    
 - [Block Buckets](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/BlockBucket)    
 - [Placeholders](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Placeholders) 
###### World optimization
 - [Border](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/World-reduction#world-border)  
 - [Trim](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/World-reduction#world-trim-intensive)  
 - [ChunkProcessor](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Chunk-processor)    
 - [Fast Async WorldEdit](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/WorldEdit-processing)    
 - [Plot analysis](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Plot-analysis)    
###### Schematics
 - [generation](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Schematic-Generation)
 - [on Claim](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Schematic-on-Claim)  
 - [exporting](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Usage:-Schematic-export)  
###### Plot 
 - [Tiers](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Plot-Rank-Tiers)  
 - [Flags](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Plot-flags)  
