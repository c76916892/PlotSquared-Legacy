﻿1. Open your `/plugins/PlotSquared/settings/worlds.yml` file.
2. Find your plotworld. (If you use ChestShop in more than one then apply the following changes to all worlds)
3. Change the following from this:
```YML
    flags: {}
```
to this:
```YML
    flags: 
      use: #signs
```
4. This will let players interact with all types and states of signs.
5. Then use `/plot reload`

**_This also applies to the SignShop Plugin and any plugin which uses signs._**
