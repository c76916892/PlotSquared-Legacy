﻿## Overview
PlotSquared offers several options related to WorldEdit. By default it will do the following if you don't have the bypass permission:
 - Restrict WorldEdit to plots
 - Block access to potentially harmful WorldEdit commands
 - Limits the max iterations with several brushes so people can't crash the server
 - Limits the max volume to 50 million

The bypass permission is `plots.worldedit.bypass`, the use `/plot toggle worldedit` or `/plot wea`

To further extend this, PlotSquared comes with a WE processor you can enable:
 - Limits max blockstates and entities with editing (enable chunk-processor)
 - Faster and async WorldEdit changes (enable experimental-fast-async-worldedit) (bypass this with `/plot wea`)

#### Other notes:
If you want to make other aspects of WorldEdit async as well, you could consider installing FAWE
 - https://www.spigotmc.org/resources/free-fast-async-worldedit-%CE%B2.13932/
