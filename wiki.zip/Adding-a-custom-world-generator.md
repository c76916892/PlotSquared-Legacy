﻿## This guide is for PlotSquared versions <= 1.12.2
## If you are not familiar with generators, here's a quick example:
 - **[[Basic example|https://forums.bukkit.org/threads/basic-creating-custom-world-generators.24569/]]**
 - **[[More detail|https://forums.bukkit.org/threads/how-to-create-custom-world-generators.79066/]]**

## How it works with PlotSquared
Each world has it's own configuration. This is wrapped in a PlotWorld class for you.
The PlotWorld class has some standard settings, but not much.
**([[Click here to take a look|https://github.com/IntellectualSites/PlotSquared/tree/master/src/main/java/com/intellectualcrafters/plot/object/PlotWorld.java]])**

PlotSquared comes with a **[[HybridPlotWorld|https://github.com/IntellectualSites/PlotSquared/tree/master/src/main/java/com/intellectualcrafters/plot/generator/HybridPlotWorld.java]]** class which has all the non generic settings we require for our generator. You are free to use this (through the API), or simply copy it if you just want to tweak a few things.

Each generator also will have it's own **[[PlotManager|https://github.com/IntellectualSites/PlotSquared/tree/master/src/main/java/com/intellectualcrafters/plot/object/PlotManager.java]]** class which determines things like plot clearing, tessellation based on the configuration of a given PlotWorld class.

PlotSquared uses the **[[HybridPlotManager|https://github.com/IntellectualSites/PlotSquared/tree/master/src/main/java/com/intellectualcrafters/plot/generator/HybridPlotManager.java]]** , which you can also use, or modify to your needs for use in a PlotSquared addon.

There are also **[[Several other|https://github.com/IntellectualSites/PlotSquared/tree/master/src/main/java/com/intellectualcrafters/plot/generator]]** PlotWorld and PlotManager classes to choose from depending on what level of abstraction you want with plot generation. For square shaped plots, you won't need to provide your own clearing algorithm, as PlotSquared can do that all for you. See the **[[SquarePlotManager class|https://github.com/IntellectualSites/PlotSquared/blob/master/src/main/java/com/intellectualcrafters/plot/generator/SquarePlotManager.java#L17-L21]]** .

Remember to have your PlotManager and PlotWorld classes match up, e.g. if you choose to use our SquarePlotManager, it is expecting a SquarePlotWorld, or higher.

## PlotSquared ChunkGenerator
With PlotSquared, instead of extending **ChunkGenerator** you will want to extend **PlotGenerator**.
This can be seen being done in our **[[HybridGen|https://github.com/IntellectualSites/PlotSquared/blob/master/src/main/java/com/plotsquared/bukkit/generator/HybridGen.java]]** class. 

You will register this PlotGenerator as you would a normal ChunkGenerator in your main class:
``` java
@Override
public ChunkGenerator getWorldGenerator(String worldName, String id) {
    return new YourPlotGenerator(worldName);
}
```
## Example PlotGenerator classes 
**(free to use/modify for a P^2 addon)**

PlotSquared: The standard generator
 - **[[HybridGen|https://github.com/IntellectualSites/PlotSquared/blob/master/Core/src/main/java/com/intellectualcrafters/plot/generator/HybridGen.java]]**
 - This generator combines normal plot generation with some features of AdvPlots for convenient, performant and highly configurable plot generation
 - It's very messy, as there are a bunch of optimizations made depending on configuration and what P^2 is doing, which you don't neccessarily need to do yourself
 
BasicPlots: Has one plot per chunk
 - **[[BasicGen|https://github.com/boy0001/BasicPlotGenerator/tree/master/src/com/boydti/basicplots]]**
 - It's fast as it generates the array for the chunk when it initializes and returns that same array for every chunk
 - The downside is that plots need to be the size of a chunk so it's not very customizable
 
PlotSquaredMG: Uses region files for generation
 - **[[MegaGen|https://github.com/boy0001/PlotSquaredMG/tree/master/src/com/boydti/psmg]]**
 - It takes ages to load up, but allows large areas of custom terrain
 - Since it's using region files, it can easily pre-generate the map on startup, and since the plot size is a multiple of 16, it calculates all the chunk arrays during startup
 - The obvious downside is the long startup time, and that plots must be huge (multiples of 512)

 
AdvPlots generator: Schematic generation
 - **[[SchemGen|http://git.intellectualsites.com/Empire92/SchemGen]]**
 - This shows that with PlotSquared you aren't limited to just squares for plots
 - It demonstrates schematic generation that works with plot merging
 - In fact if you can code it, you could provide any coordinates you want for plot locations, it doesn't have to be a grid
 
## Non PlotGenerator generators that may be useful to have a look at:
ClassicGen: One of the earliest generators used by PlotSquared:
 - **[[ClassicGen|https://github.com/boy0001/ClassicPlotGenerator/tree/master/src/com/empcraft/classic]]**
 - It's not simple, but the benefit is that there was no logic or checks inside the loops making it fairly efficient
 - Kind of the opposite of PlotMe which appears to put as much logic inside loops as it can
 - The downside to this is that it's incredibly difficult to have anything apart from simple cuboids making up the plot, so schematics in generation are out of the question 
 
Here's a generator that I wrote which has the basics of what you would expect in a plot generator:
 - **[[Source|https://gist.github.com/boy0001/e12ff4a80ad06a15ff24]]**
 - It doesn't inherit PlotGenerator, but it is documented and shows some basic optimizations and functionality
