﻿If a command or permission contains the `Other` description, it means that a command supports several sub-commands or has several purposes.    
Permissions documented with `Other` are either secondary permissions **OR** contain administrative overrides (indicated with `.admin.` inside the permission.    
Make sure to checkout our [permission packs](https://github.com/IntellectualSites/PlotSquared/wiki/Permission-Packs) to avoid redundant permission assignments.

# Contents
###### CLAIMING
 - [/plot buy](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#buy)    
 - [/plot claim](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#claim)    
 - [/plot auto](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#auto)    
 - [/plot delete](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#delete)    
 - [/plot swap](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#swap)    
 - [/plot move](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#move)    
 - [/plot copy](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#copy)    
 - [/plot grant](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#grant)    
 - [/plot setowner](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#setowner)    

###### TELEPORT
 - [/plot visit](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#visit)    
 - [/plot kick](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#kick)    
 - [/plot middle](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#middle)    

###### SETTINGS
 - [/plot trust](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#trust)    
 - [/plot add](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#add)    
 - [/plot deny](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#deny)    
 - [/plot remove](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#remove)    
 - [/plot merge](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#merge)    
 - [/plot unlink](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#unlink)    
 - [/plot trust](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#trust)    
 - [/plot setflag](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#setflag)    
 - [/plot done](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#done)    
 - [/plot continue](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#continue)    
 - [/plot setdescription](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#setdescription)    
 - [/plot alias](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#alias)    
 - [/plot sethome](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#sethome)    
 - [/plot toggle](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#toggle)    

###### CHAT
 - [/plot inbox](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#inbox)    
 - [/plot comment](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#comment)    
 - [/plot chat](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#chat)    

###### SCHEMATIC
 - [/plot save](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#save)    
 - [/plot load](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#load)    
 - [/plot download](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#download)    
 - [/plot schematic](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#schematic-1)    
 - [/plot bo3](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#bo3)    

###### APPEARANCE
 - [/plot set](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#set)    
 - [/plot clear](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#clear)    
 - [/plot music](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#music)    
 - [/plot setbiome](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#setbiome)    

###### INFO
 - [/plot confirm](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#confirm)    
 - [/plot info](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#info-1)    
 - [/plot list](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#list)    
 - [/plot plugin](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#plugin)    
 - [/plot rate](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#rate)    
 - [/plot target](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#target)    
 - [/plot help](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#help) 
 - [/plot caps](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#caps)       

###### DEBUG
 - [/plot debugsavetest](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#debugsavetest)    
 - [/plot debugloadtest](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#debugloadtest)    
 - [/plot debugallowunsafe](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#debugallowunsafe)    
 - [/plot debug](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#debug)    
 - [/plot relight](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#relight)    
 - [/plot debugpaste](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#debugpaste)    
 - [/plot debugclaimtest](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#debugclaimtest)    
 - [/plot debugroadregen](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#debugroadregen)    
 - [/plot debugexec](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#debugexec)    
 - [/plot debugfixflags](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#debugfixflags)    

###### ADMINISTRATION
 - [/plot update](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#update)    
 - [/plot template](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#template)    
 - [/plot setup](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#setup)    
 - [/plot area](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#area)    
 - [/plot createroadschematic](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#createroadschematic)    
 - [/plot regenallroads](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#regenallroads)    
 - [/plot purge](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#purge)    
 - [/plot reload](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#reload)    
 - [/plot database](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#database)    
 - [/plot condense](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#condense)    
 - [/plot trim](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#trim)    
 - [/plot cluster](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#cluster)    
 - [/plot weanywhere](https://github.com/IntellectualSites/PlotSquared/wiki/Commands#weanywhere)    

# Commands
## [BUY](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Buy.java)    
#### Description
`Buy the plot you are standing on`
#### Usage    
`/plot buy`    
#### Permissions
`plots.buy`    
***

## [SAVE](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Save.java)    
#### Description
`Save your plot`
#### Usage    
`/plot save`    
#### Aliases
`[ backup ]`
#### Permissions
##### Primary
 - `plots.save`    
***

## [LOAD](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Load.java)    
#### Description
`Load your plot`
#### Usage    
 - `/plot restore`    
##### Other    
 - `/plot load <index>`    
#### Aliases
`[ load,restore ]`
#### Permissions
##### Primary
 - `plots.load`    
***

## [CONFIRM](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Confirm.java)    
#### Description
`Confirm an action`
#### Usage    
`/plot confirm`    
#### Aliases
`[ confirm ]`
#### Permissions
`plots.use`    
***

## [TEMPLATE](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Template.java)    
#### Description
`Create or use a world template`
#### Usage    
##### Primary    
 - `/plot template [import|export] <world> <template>`    

##### Other    
 - `/plot template <import|export> <world> [template]`
 - `/plot template export <world>`
 - `/plot template import <world> <template>`    

#### Aliases
`[ template ]`
#### Permissions
`plots.admin`    
***

## [DOWNLOAD](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Download.java)    
#### Description
`Download your plot`
#### Usage    
`/plot download [schematic|world]`    
#### Aliases
`[ download,dl ]`
#### Permissions
 - `plots.download`    
 - `plots.download.world`
***

## [SETUP](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Setup.java)    
#### Description
`Setup wizard for plot worlds`
#### Usage    
`/plot setup`    
#### Aliases
`[ setup,create ]`
#### Permissions
`plots.admin.command.setup`    
***

## [AREA](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Area.java)    
#### Description
`Create a new PlotArea`
#### Usage    
##### Primary    
 - `/plot area <create|info|list|tp|regen>`    

##### Other    
 - `/plot visit [area]`
 - `info [area]`
 - `create [world[:id]] [<modifier>=<value>]...`
 - `/plot area create [world[:id]] [<modifier>=<value>]...`
 - `list [#]`    

#### Aliases
`[ area,world ]`
#### Permissions
 - `plots.area`    
 - `plots.area.list`
 - `plots.area.info`
 - `plots.area.create`
 - `plots.area.tp`
 - `plots.area.regen`
***

## [DEBUGSAVETEST](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/DebugSaveTest.java)    
#### Description
`This command will force the recreation of all plots in the DB`
#### Usage    
`/plot debugsavetest`    
#### Aliases
`[ debugsavetest ]`
#### Permissions
`plots.debugsavetest`    
***

## [DEBUGLOADTEST](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/DebugLoadTest.java)    
#### Description
`This debug command will force the reload of all plots in the DB`
#### Usage    
`/plot debugloadtest`    
#### Aliases
`[ debugloadtest ]`
#### Permissions
`plots.debugloadtest`    
***

## [CREATEROADSCHEMATIC](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/CreateRoadSchematic.java)    
#### Description
`Add a road schematic to your world using the roads around your current plot`
#### Usage    
`/plot createroadschematic`    
#### Aliases
`[ createroadschematic,crs ]`
#### Permissions
`plots.createroadschematic`    
***

## [DEBUGALLOWUNSAFE](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/DebugAllowUnsafe.java)    
#### Description
`Allow unsafe actions until toggled off`
#### Usage    
`/plot debugallowunsafe`    
#### Aliases
`[ debugallowunsafe ]`
#### Permissions
`plots.debugallowunsafe`    
***

## [REGENALLROADS](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/RegenAllRoads.java)    
#### Description
`Regenerate all roads in the map using the set road schematic`
#### Usage    
`/plot regenallroads <world> [height]`    
#### Aliases
`[ regenallroads,rgar ]`
#### Permissions
`plots.regenallroads`    
***

## [CLAIM](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Claim.java)   
#### Description
`Claim the current plot you're standing on.
If you activated the "specify_on_claim" option in the worlds.yml you can define a plot-schematic.`
#### Usage
 - `/plot claim`
##### Other    
 - `/plot claim <schematic>`
#### Aliases
`[ claim,c ]`
#### Permissions
 - `plots.claim`    
 - `plots.plot.<#>`
 - `plots.claim." + schematic`
 - `plots.claim.<arg>`
 - `plots.admin.command.schematic`
***

## [AUTO](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Auto.java)    
#### Description
`Claim the nearest plot`
#### Usage    
`/plot auto [length,width]`    
#### Aliases
`[ auto,a ]`
#### Permissions
 - `plots.auto`    
 - `plots.plot.<#>`
 - `plots.claim." + schematic`
 - `plots.auto.mega`
 - `plots.claim.<arg>`
 - `plots.admin.command.schematic`
***

## [VISIT](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Visit.java)    
#### Description
`Visit someones plot`
#### Usage   
 - `/plot visit [player|alias|world|id] [#]`    
 - `/plot visit <world>;<id> [#]`    
#### Aliases
`[ visit,v,tp,teleport,goto,home,h ]`
#### Permissions
 - `plots.visit`    
##### Other
 - `plots.visit.unowned`
 - `plots.home`
 - `plots.visit.owned`
 - `plots.visit.shared`
 - `plots.visit.other`
***

## [SET](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Set.java)    
#### Description
`Set a plot value`
#### Usage    
`/plot set <biome|alias|home|flag> <value...>`    
#### Aliases
`[ set,s ]`
#### Permissions
 - `plots.set`    
##### Other
 - `plots.set." + component`
 - `plots.set.<arg>`
***

## [CLEAR](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Clear.java)    
#### Description
`Clear a plot`
#### Usage    
`/plot clear`    
#### Aliases
`[ clear,reset ]`
#### Permissions
 - `plots.clear`    
##### Other
 - `plots.admin.command.clear`
 - `plots.continue`
***

## [DELETE](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Delete.java)    
#### Description
`Delete a plot`
#### Usage    
`/plot delete`    
#### Aliases
`[ delete,dispose,del,reset ]`
#### Permissions
 - `plots.delete`    
##### Other
 - `plots.admin.command.delete`
***

## [TRUST](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Trust.java)    
#### Description
`Allow a user to build in a plot and use WorldEdit while the plot owner is offline.`
#### Usage    
`/plot trust <player|*>`    
#### Aliases
`[ trust,t ]`
#### Permissions
 - `plots.trust`    
##### Other
 - `plots.admin.command.trust`
 - `plots.trust.everyone`
***

## [ADD](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Add.java)    
#### Description
`Allow a user to build in a plot while the plot owner is online.`
#### Usage    
`/plot add <player|*>`    
#### Permissions
 - `plots.add`    
##### Other
 - `plots.admin.command.trust`
 - `plots.trust.everyone`
***

## [DENY](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Deny.java)    
#### Description
`Deny a user from a plot`
#### Usage    
`/plot deny <player|*>`    
#### Aliases
`[ deny,d,ban ]`
#### Permissions
 - `plots.deny`    
##### Other
 - `plots.admin.command.deny`
 - `plots.deny.everyone`
***

## [REMOVE](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Remove.java)    
#### Description
`Remove a player from a plot`
#### Usage    
`/plot remove <player|*>`    
#### Aliases
`[ remove,r,untrust,ut,undeny,ud,unban ]`
#### Permissions
 - `plots.remove`    
##### Other
 - `plots.admin.command.remove`
***

## [INFO](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Info.java)    
#### Description
`Display plot info`
#### Usage    
`/plot info <id>`    
#### Aliases
`[ info,i ]`
#### Permissions
`plots.info`    
***

## [LIST](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/ListCmd.java)    
#### Description
`List plots`
#### Usage    
 - `/plot list <forsale|mine|shared|world|top|all|unowned|unknown|player|world|done|fuzzy <search...>> [#]`    
##### Other    
 - `/plot list fuzzy <search...> [#]`    
#### Aliases
`[ list,l,find,search ]`
#### Permissions
 - `plots.list`    
##### Other
 - `plots.list.world.<arg>`
 - `plots.list.top`
 - `plots.list.mine`
 - `plots.list.world`
 - `plots.list.done`
 - `plots.list.all`
 - `plots.list.shared`
 - `plots.list.expired`
 - `plots.list.unowned`
 - `plots.list.world." + world`
 - `plots.list.player`
 - `plots.list.forsale`
 - `plots.list.world." + args[0]`
 - `plots.list.unknown`
 - `plots.list.area`
 - `plots.list.fuzzy`
***

## [DEBUG](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Debug.java)    
#### Description
`Show debug information`
#### Usage    
`/plot debug [msg]`    
#### Aliases
`[ debug ]`
#### Permissions
`plots.admin`    
***

## [SCHEMATIC](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/SchematicCmd.java)    
#### Description
`Schematic command`
#### Usage    
`/plot schematic <arg...>`    
#### Aliases
`[ schematic,sch ]`
#### Permissions
 - `plots.schematic`    
##### Other
 - `plots.admin.command.schematic.paste`
 - `plots.admin.command.schematic.save`
 - `plots.schematic.test`
 - `plots.schematic.save`
 - `plots.schematic.paste`
***

## [PLUGIN](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/PluginCmd.java)    
#### Description
`Show plugin information`
#### Usage    
`/plot plugin`    
#### Aliases
`[ plugin,version ]`
#### Permissions
`plots.use`    
***

## [PURGE](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Purge.java)    
#### Description
`Purge all plots for a world`
#### Usage    
`/plot purge world:<world> area:<area> id:<id> owner:<owner> shared:<shared> unknown:[true|false]`    
#### Aliases
`[ purge ]`
#### Permissions
`plots.admin`    
***

## [RELOAD](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Reload.java)    
#### Description
`Reload translations and world settings`
#### Usage    
`/plot reload`    
#### Aliases
`[ reload ]`
#### Permissions
`plots.admin.command.reload`    
***

## [RELIGHT](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Relight.java)    
#### Description
`Relight your plot`
#### Usage    
`/plot relight`    
#### Aliases
`[ relight ]`
#### Permissions
`plots.relight`    
***

## [MERGE](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Merge.java)    
#### Description
`Merge the plot you are standing on, with another plot`
#### Usage    
 - `/plot merge <all|n|e|s|w> [removeroads]`    
##### Other    
 - `/plot merge < <arg> | <arg> > [removeroads]`    
#### Aliases
`[ merge,m ]`
#### Permissions
 - `plots.merge`    
##### Other
 - `plots.merge.<#>`
 - `plots.admin.command.merge`
 - `plots.merge.other`
 - `plots.merge.keeproad`
***

## [DEBUGPASTE](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/DebugPaste.java)    
#### Description
`Upload settings.yml, worlds.yml, your latest.log and Multiverse's worlds.yml (if being used) to https://athion.net/ISPaster/paste`
#### Usage    
`/plot debugpaste`    
#### Aliases
`[ debugpaste,dp ]`
#### Permissions
`plots.debugpaste`    
***

## [UNLINK](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Unlink.java)    
#### Description
`Unlink a mega-plot (merged plot)`
#### Usage    
`/plot unlink`    
#### Aliases
`[ unlink,u,unmerge ]`
#### Permissions
 - `plots.unlink`    
##### Other
 - `plots.admin.command.unlink`
***

## [KICK](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Kick.java)    
#### Description
`Kick a player from your plot`
#### Usage    
`/plot kick <player>`    
#### Aliases
`[ kick,k ]`
#### Permissions
 - `plots.kick`    
##### Other
 - `plots.admin.command.kick`
***

## [RATE](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Rate.java)    
#### Description
`Rate the plot`
#### Usage    
`/plot rate [#|next]`    
#### Aliases
`[ rate,rt ]`
#### Permissions
 - `plots.rate`    
##### Other
 - `plots.comment`
***

## [DEBUGCLAIMTEST](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/DebugClaimTest.java)    
#### Description
`If you accidentally delete your database, this command will attempt to restore all plots based on the data from plot signs. Execution time may vary.`
#### Usage    
`/plot debugclaimtest`    
#### Aliases
`[ debugclaimtest ]`
#### Permissions
`plots.debugclaimtest`    
***

## [INBOX](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Inbox.java)    
#### Description
`Review the comments for a plot`
#### Usage    
`/plot inbox [inbox] [delete <index>|clear|page]`    
#### Aliases
`[ inbox ]`
#### Permissions
`plots.inbox`    
***

## [COMMENT](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Comment.java)    
#### Description
`Comment on a plot`
#### Usage    
`/plot comment`    
#### Aliases
`[ comment,msg ]`
#### Permissions
`plots.comment`    
***

## [DATABASE](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Database.java)    
#### Description
`Convert/Backup Storage`
#### Usage    
`/plots database [area] <sqlite|mysql|import>`    
#### Aliases
`[ database,convert ]`
#### Permissions
`plots.database`    
***

## [SWAP](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Swap.java)    
#### Description
`Swap two plots`
#### Usage    
 - `/plot swap <X;Z>`    
#### Aliases
`[ swap,switch ]`
#### Permissions
 - `plots.swap`    
##### Other
 - `plots.admin`
***

## [MUSIC](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Music.java)    
#### Description
`Player music in a plot`
#### Usage    
`/plot music`    
#### Aliases
`[ music ]`
#### Permissions
`plots.music`    
***

## [DEBUGROADREGEN](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/DebugRoadRegen.java)    
#### Description
`Regenerate all roads based on the road schematic. Insert "plot" to regen it from the plot height, input "height [height]" to regen from a custom height.`
#### Usage    
`/plot debugroadregen <plot|height [height]>`    
#### Aliases
`[ debugroadregen ]`
#### Permissions
`plots.debugroadregen`    
***

## [DEBUGEXEC](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/DebugExec.java)    
#### Description
`Multi-purpose debug command`
#### Usage    
 - `/plot debugexec`    
##### Other    
 - `/plot debugexec remove-flag <flag>`
 - `/plot debugexec allcmd <condition> <command>`
 - `/plot debugexec list-scripts [#]`
 - `/plot debugexec all <condition> <code>`
 - `/plot debugexec addcmd <file>`
 - `/plot debugexec analyze <threshold>`    
#### Aliases
`[ debugexec,exec,$ ]`
#### Permissions
`plots.admin`    
***

## [SETFLAG](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/FlagCmd.java)    
#### Description
`Set plot flags`
#### Usage    
 - `/plot flag <set|remove|add|list|info> <flag> <value>`    
##### Other    
 - `/plot flag info <flag>`
 - `/plot flag <set|remove|add|list|info>`
 - `/plot flag add <flag> <values>`
 - `/plot flag list`
 - `/plot flag set <flag> <value>`
 - `/plot flag remove <flag> [values]`    
#### Aliases
`[ setflag,f,flag,setf ]`
#### Permissions
 - `plots.flag`    
##### Other
 - `plots.set.flag`
 - `plots.flag.remove`
 - `plots.flag.add`
 - `plots.set.flag.other`
 - `plots.set.flag.<arg>`
 - `plots.flag.list`
 - `plots.set.flag." + args[1].toLowerCase`
***

## [TARGET](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Target.java)    
#### Description
`Target a plot with your compass`
#### Usage    
`/plot target <<plot>|nearest>`    
#### Aliases
`[ target ]`
#### Permissions
`plots.target`    
***

## [DEBUGFIXFLAGS](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/DebugFixFlags.java)    
#### Description
`Attempt to fix all flags for a world`
#### Usage    
`/plot debugfixflags <world>`    
#### Aliases
`[ debugfixflags ]`
#### Permissions
`plots.debugfixflags`    
***

## [MOVE](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Move.java)    
#### Description
`Move a plot`
#### Usage    
 - `/plot move <X;Z>`    
#### Aliases
`[ move,debugmove ]`
#### Permissions
 - `plots.move`    
##### Other
 - `plots.admin`
***

## [CONDENSE](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Condense.java)    
#### Description
`Condense a plotworld`
#### Usage    
`/plot condense`    
#### Aliases
`[ condense ]`
#### Permissions
`plots.admin`    
***

## [COPY](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Copy.java)    
#### Description
`Copy a plot`
#### Usage    
`/plot copy <X;Z>`    
#### Aliases
`[ copy,copypaste ]`
#### Permissions
 - `plots.copy`    
##### Other
 - `plots.admin`
***

## [CHAT](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Chat.java)    
#### Description
`Toggle plot chat on or off`
#### Usage    
`/plot chat [on|off]`    
#### Aliases
`[ chat ]`
##### Primary
 - `plots.chat`    
##### Other
 - `plots.chat.color`
***

## [TRIM](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Trim.java)    
#### Description
`Delete unmodified portions of your plotworld`
##### Comments
``` java
Runs the result task with the parameters (viable, nonViable).
@param world The world
@param result (viable = .mcr to trim, nonViable = .mcr keep)
@return
```
#### Usage    
`/plot trim <world> [regenerate]`    
#### Aliases
`[ trim ]`
#### Permissions
`plots.admin`    
***

## [DONE](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Done.java)    
#### Description
`Mark a plot as done`
#### Usage    
`/plot done`    
#### Aliases
`[ done,submit ]`
#### Permissions
##### Primary
 - `plots.done`    
##### Other
 - `plots.admin.command.done`
***

## [CONTINUE](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Continue.java)    
#### Description
`Continue a plot that was previously marked as done`
#### Usage    
`/plot continue`    
#### Aliases
`[ continue ]`
#### Permissions
 - `plots.continue`    
##### Other
 - `plots.admin.command.continue`
***

## [MIDDLE](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Middle.java)    
#### Description
`Teleports you to the center of the current plot`
#### Usage    
`/plot middle`    
#### Aliases
`[ middle,center ]`
#### Permissions
`plots.middle`    
***

## [GRANT](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Grant.java)    
#### Description
``
#### Usage    
`/plot grant <check|add> [player]`    
#### Aliases
`[ grant ]`
#### Permissions
 - `plots.grant`    
##### Other
 - `plots.grant." + arg`
 - `plots.grant.<arg>`
***

## [SETOWNER](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Owner.java)    
#### Description
`Set the plot owner`
#### Usage    
`/plot setowner <player>`    
#### Aliases
`[ setowner,owner,so,seto ]`
#### Permissions
##### Primary
 - `plots.set.owner`    
##### Other
 - `plots.admin.command.setowner`
***

## [SETDESCRIPTION](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Desc.java)    
#### Description
`Set the plot description`
#### Usage    
`/plot desc <description>`    
#### Aliases
`[ setdescription,desc,setdesc,setd,description ]`
#### Permissions
`plots.set.desc`    
***

## [SETBIOME](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Biome.java)    
#### Description
`Set the plot biome`
#### Usage    
`/plot biome [biome]`    
#### Aliases
`[ setbiome,biome,sb,setb,b ]`
#### Permissions
`plots.set.biome`    
***

## [ALIAS](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Alias.java)    
#### Description
`Set the plot name`
#### Usage    
`/plot alias set <alias>`    
`/plot alias remove <alias>`    
#### Aliases
`[ setalias,alias,sa,name,rename,setname,seta, nameplot ]`
#### Permissions
`plots.alias.set`
`plots.alias.remove`
***

## [SETHOME](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/SetHome.java)    
#### Description
`Set the plot home`
#### Usage    
`/plot sethome [none]`    
#### Aliases
`[ sethome,sh,seth ]`
#### Permissions
`plots.set.home`    
***

## [CLUSTER](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Cluster.java)    
#### Description
`Manage a plot cluster`
#### Usage    
 - `/plot cluster`    
##### Other    
 - `/plot cluster resize <pos1> <pos2>`
 - `/plot cluster leave [name]`
 - `/plot cluster info [name]`
 - `/plot cluster create <name> <id-bot> <id-top>`
 - `/plot cluster delete [name]`
 - `/plot cluster list`
 - `/plot cluster invite <player>`
 - `/plot cluster sethome`
 - `/plot cluster helpers <add|remove> <player>`
 - `/plot cluster tp <name>`
 - `/plot cluster kick <player>`    
#### Aliases
`[ cluster,clusters ]`
#### Permissions
 - `plots.cluster`    
##### Other
 - `plots.cluster.delete.other`
 - `plots.cluster.kick`
 - `plots.cluster.leave`
 - `plots.cluster.helpers`
 - `plots.cluster.create`
 - `plots.cluster.resize`
 - `plots.cluster.invite.other`
 - `plots.cluster.invite`
 - `plots.cluster.tp`
 - `plots.cluster.<#>`
 - `plots.cluster.resize.expand`
 - `plots.cluster.info`
 - `plots.cluster.sethome.other`
 - `plots.cluster.resize.other`
 - `plots.cluster.tp.other`
 - `plots.cluster.kick.other`
 - `plots.cluster.create.other`
 - `plots.cluster.list`
 - `plots.cluster.delete`
 - `plots.cluster.resize.shrink`
 - `plots.cluster.sethome`
***

## [TOGGLE](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Toggle.java)    
#### Description
`Toggle per user settings`
#### Usage    
`/plot toggle [worldedit|chat|chatspy|titles|time]`    
#### Aliases
`[ toggle,attribute ]`
#### Permissions
`plots.use`    
***

## [HELP](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Help.java)    
#### Description
`Get this help menu`
#### Usage    
`/plot help help [category|#]`    
#### Aliases
`[ help,he,? ]`
#### Permissions
`plots.use`    
***

## [CAPS](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/Caps.java)    
#### Description
`Show plot mob and entity caps`
#### Usage    
`/plot caps`    
#### Permissions
`plots.caps`    
***

## [WEANYWHERE](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/commands/WE_Anywhere.java)    
#### Description
`Force bypass of WorldEdit restrictions`
#### Usage    
`/plot weanywhere`    
#### Aliases
`[ weanywhere,wea ]`
#### Permissions
`plots.worldedit.bypass`    
***
