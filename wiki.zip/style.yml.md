﻿The style.yml determines the color of the dollar codes used in the translation file:
[PlotSquared.use_THIS.yml](https://github.com/IntellectualCrafters/PlotSquared/wiki/Translations)

On the left are the dollar (`$`) codes, and the right are the corresponding ampersand (`&`) codes.

```yml
Information: 'Left Row: PlotSquared color codes ($), right row: Minecraft color codes
  (&)'
color:
  '12': b
  '13': c
  '14': d
  '15': e
  '10': '0'
  '11': a
  '3': '8'
  '4': '3'
  '5': '1'
  '6': '2'
  '7': '4'
  '16': f
  '8': '5'
  '9': '9'
  '1': '6'
  '2': '7'
```
This allows for convenient changing of the PlotSquared color scheme. Please note that you are not required to use the dollar codes, they are just there to make styling easier.

### Colors:
![http://i.imgur.com/RbcmjNZ.png](http://i.imgur.com/RbcmjNZ.png)
