﻿#### Enable PlotMe alias
If you would like `/plotme` to work, please enable `plotme-alias` in the `settings.yml`
This will not mimic any subcommands. See below for further alias configuration

#### commands.yml
The `commands.yml` can be found in `plugins/PlotSquared/config/commands.yml` and allows you to dynamically modify aliases for commands
