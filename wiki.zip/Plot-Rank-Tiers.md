﻿## Content
#### The following tiers of memberships are available:

## Denied:
 - Cannot edit the plot
 - Cannot enter the plot

## Guest:
 - Cannot edit the plot
 - Can enter the plot

## Member:
 - Can enter the plot
 - Can place / break blocks while the plot owner is online

## Trusted:
 - Can enter the plot
 - Can place / break blocks even if the plot owner is offline
 - Can use WorldEdit on the plot

## Owner:
 - Has full control over the plot
 - Adding or removing users
 - Can place / break blocks
 - Use WorldEdit
