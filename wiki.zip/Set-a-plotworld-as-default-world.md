﻿Setting a plot world as default world can help you to avoid the generation of the default worlds.


In the following guide we assume you called the plotworld `plotworld` and you need solely the plotworld, if yours is called differently, just replace it with your name.


## Initial Steps
1. Shut down the server
2. Delete the vanilla worlds `world`, `world_nether` and `world_the_end` like selected below: <br>
![](https://i.imgur.com/6kAMx34.png)
## server.properties
Open the file called `server.properties`, it's stored in your server's root folder.

Find the following line:
```properties
level-name=world
```
Replace `world` with the name of your plot world. In this example case, we would need to name it to `plotworld`.
So it looks like that:
```properties
level-name=plotworld
```
## bukkit.yml
Open the file called `bukkit.yml`, it's stored in your server's root folder.
Now we need to tell the server which generator based on the world should be generated, **otherwise your world generation will be messed up**.

The value we are going to edit does not exist in the file yet, so we need to add it at the bottom:
```yaml
worlds:
  plotworld:
    generator: PlotSquared
```
That's it. If you are using world management plugins, such as Multiverse-Core, you need to make sure to set `PlotSquared` as generator in their worlds.yml too.
