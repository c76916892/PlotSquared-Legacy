﻿## This guide is for PlotSquared versions <= 1.12.2
### Disclaimer
This is a new feature, not a magical solution to all your problems. The chunk processor isn't perfect, and it is your fault if it fails to prevent lag / crashes (Although feel free to create a ticket if you think it's something it could prevent in future).

It is however very efficient, and will hardly leave a footprint when there are no chunks to process.

### Overview
The chunk processor will process chunks before they are saved / loaded from disk. It is lightweight at the moment with the following capabilities:
 - Clear entities if a dangerous amount is detected
 - Clear blockstates if a dangerous amount is detected

The purpose of the processor is to:
 - Decrease server lag
 - Prevent potentially dangerous chunks being saved / loaded from disk
 - Prevent repeated server crashes from dangerous chunks

The usual causes of dangerous chunks are:
 - People abusing WorldEdit
 - People abusing VoxelSniper
 - Any other tool you have that can be used to spam entites / blocks

### Configuration
Configuration is done through the `settings.yml`
##### Enabling
``` YML
chunk-processor:
// If the processor is enabled
  enabled: true
// The maximum number of blockstates allowed per chunk
  max-blockstates: 4096
/// The maximum number of entities required in a chunk before it is deemed a source of lag
  max-entities: 512
// If you also want to disable all physics
// (formerly there was a physics limiter, however that lead to confusion when important things like redstone were limited, so now it is just a blanket disable option)
  disable-physics: false
// Auto trim will not save chunks on unload if they do not belong to a claimed plot
// As chunks may save without unloading, it is recommended to disable world autosaving, or enable auto-unload
  auto-trim: true
// This will replace chunk unloading with something a bit more aggressive.
  auto-unload: true
// See here: https://github.com/IntellectualSites/PlotSquared/wiki/WorldEdit-processing
  experimental-fast-async-worldedit: true
```

For more information about blockstates see:
https://hub.spigotmc.org/javadocs/spigot/org/bukkit/block/package-tree.html
(or do a google search)
