﻿[![Spigot Downloads](https://img.shields.io/badge/dynamic/json.svg?url=https://api.spiget.org/v2/resources/1177&label=Spigot-Downloads&query=$.downloads&colorB=ee8a18&style=flat-square&maxAge=3600)](https://www.spigotmc.org/resources/plotsquared.1177/)
[![Discord](https://img.shields.io/discord/268444645527126017.svg?style=flat-square&maxAge=3600&colorB=7289DA)](https://discord.gg/KxkjDVg)
