﻿# API Documentation for PlotSquared

**This is v5 only!**

## JavaDoc

JavaDocs are available via: https://plotsquared.com/docs/

## Maven

If you need to access the Bukkit module of PlotSquared, you need to add `plotsquared-bukkitapi` as `<artifactId>` and declare it as non-transitive.
    
You need to add the WorldEdit repository as well.
```xml
<!-- WorldEdit -->
<repository>
    <id>enginehub</id>
    <url>https://maven.enginehub.org/repo/</url>
</repository>
<repository>
    <id>plotsquared</id>
    <url>https://plotsquared.com/mvn/</url>
</repository>

<!-- PlotSquared API -->
<dependency>
  <groupId>com.plotsquared</groupId>
  <artifactId>plotsquared-api/artifactId>
  <version>3.1</version>
</dependency>
```

## Bukkit: Gradle
If you need to access the bukkit module of PlotSquared, you need to add `plotsquared-bukkitapi` into the `dependencies` block and declare it as non-transitive.
```gradle
repositories {
    maven { url = "https://maven.enginehub.org/repo/" } // WorldEdit
    maven { url = "https://plotsquared.com/mvn/" } // PlotSquared
}

// PlotSquared API
dependencies {
    implementation("com.plotsquared:PlotSquared:3.1")
}
```
You can compile PlotSquared with Gradle, which is included with this repository:    
$ `gradlew build`      

## Useful classes for PlotSquared
[[PlotAPI|https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/api/PlotAPI.java]]  
[[PlotPlayer|https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/object/PlotPlayer.java]]    
[[Plot|https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/object/Plot.java]]    
[[FlagManager|https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/flag/FlagManager.java]]  
[[MainUtil|https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/util/MainUtil.java]]  
[[SchematicHandler|https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/util/SchematicHandler.java]]  
[[ChunkManager|https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/util/ChunkManager.java]]  
[[UUIDHandler|https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/util/UUIDHandler.java]]

## Tutorials
[Scripting with javascript](https://github.com/IntellectualSites/PlotSquared/wiki/Scripting)    
[Creating Flags in v5](https://github.com/IntellectualSites/PlotSquared/wiki/API-Flag)

## Terminology:
#### Plot area:
A plot area is any area that PlotSquared will manage/handle. If this is an infinite plot world, the entire world is considered to be a plot area. If you use plot clusters, then only part of the world will be a plot area, and anything outside this area will not be handled by PlotSquared.

See: [MainUtil.java](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/util/MainUtil.java)#getPlotAreaByString(...)

#### Clusters
Clusters can be created within existing plot areas, or they can be created in a previously non-plot world, which will in turn create it's own plot area.

See: [PlotCluster.java](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/object/PlotCluster.java)
See: [PlotSquared.java](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/PlotSquared.java(...))

#### Road
A road is what separates each plot, and includes the wall around each plot. Attempting to get a plot at this location will return null.

See: [Location.java](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/object/Location.java)#isPlotRoad(...)

#### Plot
A plot can be claimed or unclaimed. Getting a plot at a location where one isn't claimed will return a new unowned plot object.

See: [MainUtil.java](https://github.com/IntellectualSites/PlotSquared/blob/v5/Core/src/main/java/com/github/intellectualsites/plotsquared/plot/util/MainUtil.java)#getPlots(...)

>If you have made a tutorial, or an addon for PlotSquared, and want us to link it here, please create an issue. We'd really appreciate it!
