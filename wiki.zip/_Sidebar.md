﻿#### [Home](https://github.com/IntellectualCrafters/PlotSquared/wiki)
#### [API documentation](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/API-Documentation)
- [Scripting](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Scripting) 
#### Installation
- [Installation](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Installation)  
###### World Creation   
- [Standard Creation](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Installation)  
###### Further installation
- [Road schematics](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Installation#adding-road-schematics)  
- [settings.yml](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/settings.yml)    
- [commands.yml](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/commands.yml)    
- [worlds.yml](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/worlds.yml)    
- [style.yml](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/style.yml)     
- [UUID conversion](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/UUID-conversion)    
- [Set a plot world as default world](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Set-a-plotworld-as-default-world)         
- [ChestShop Compatibility](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/ChestShop-Compatibility)
#### Commands
- [Commands and Permissions](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Commands)     
- [Administrative Permissions](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Bypass-Permissions)  
###### Customization
- [Translation](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/PlotSquared.use_THIS.yml)
- [Command aliases](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/aliases)    
- [Block Buckets](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/BlockBucket)    
- [Placeholders](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Placeholders)
###### World optimization
- [Condensation](https://github.com/IntellectualCrafters/PlotSquared/wiki/World-reduction#plot-condensation-added-in-275-intensive)  
- [Trim](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/World-reduction#world-trim-intensive)  
- [ChunkProcessor](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Chunk-processor)    
- [Fast Async WorldEdit](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/WorldEdit-processing)    
- [Plot analysis](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Plot-analysis)    
###### World types
- [Augmented](https://github.com/IntellectualCrafters/PlotSquared/wiki/TerrainControl)    
- [Augmented-Partial](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Augmented-Plot-Worlds)  
###### Schematics
- [generation](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Schematic-Generation) / [on Claim](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Schematic-on-Claim)  
- [exporting](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Usage:-Schematic-export)  
###### Plot 
- [Tiers](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Plot-Rank-Tiers)  
- [Flags](https://github.com/IntellectualSites/PlotSquared-Legacy/wiki/Plot-flags)
