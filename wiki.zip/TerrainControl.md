﻿## This guide is for PlotSquared versions <= 1.12.2
#### For partial plot areas, see [Here](https://github.com/IntellectualCrafters/PlotSquared/wiki/Augmented-Plot-Worlds)

## Using the `/plot area` command. 
 - /plot area create ＜world＞ type=1 terrain=? ＜modifiers＞
 - /plot confirm

Modifiers (optional):
 - type (0 = standard plotworld (new world), 1 = augmented full (new world), 2 = augmented partial)
 - terrain (0 = flat, 1=flat + ores, 2=roads, 3=no change)
 - size of the plot
 - gap (road + border)
 - main
 - floor
 - wall
 - border
 - height (height + 1 = y-coordinate for the border block)

You can regenerate the entire area using:
`/plot area regen` (e.g. If you want to change the settings)

## Alternatively use the setup command (mostly obsolete)
#### Step 1: Create a world
This will also work any existing world you have, e.g. Using the Terrain control generator:
See: https://github.com/MCTCP/TerrainControl/wiki

#### Clusters
If you only want clusters, see the cluster tutorial:
https://github.com/IntellectualCrafters/PlotSquared/wiki/Augmented-Plot-Worlds

#### Augmented:
 - Use /plot setup
 - Choose "Augmented" as the world type
 - Complete the setup

## Image
![http://i.imgur.com/hNymF10.jpg](http://i.imgur.com/hNymF10.jpg)
